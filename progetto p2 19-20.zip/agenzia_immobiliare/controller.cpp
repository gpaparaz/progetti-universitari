#include "controller.h"

controller::controller(QObject*parent): QObject(parent), m(new model()),  view(new mainwindow()), ins(new addimmobilewindow()), mod(new modimmobilewindow())
{
    connect(view,SIGNAL(signalFiltroAppartamento()),this,SLOT(slotFiltroAppartamento()));
    connect(view,SIGNAL(signalFiltroTerreno()),this,SLOT(slotFiltroTerreno()));
    connect(view,SIGNAL(signalFiltroTerrenoAgricolo()),this,SLOT(slotFiltroTerrenoAgricolo()));
    connect(view,SIGNAL(signalFiltroTerrenoEdificabile()),this,SLOT(slotFiltroTerrenoEdificabile()));
    connect(view,SIGNAL(signalFiltroVilla()),this,SLOT(slotFiltroVilla()));
    connect(view,SIGNAL(signalFiltroVillaSingola()),this,SLOT(slotFiltroVillaSingola()));
    connect(view,SIGNAL(signalFiltroAffittabile()),this,SLOT(slotFiltroAffittabile()));
    connect(view,SIGNAL(signalFiltroInVendita()),this,SLOT(slotFiltroInVendita()));
    connect(view,SIGNAL(signalRimuoviFiltro()),this,SLOT(slotRimuoviFiltro()));
    connect(view, SIGNAL(signalFiltroAppAttico()),this, SLOT(slotFiltroAppAttico()));
    connect(view,SIGNAL(signalFiltroAppSpese()),this, SLOT(slotFiltroAppSpese()));
    connect(view,SIGNAL(signalFiltroVillaSchiera()),this, SLOT(slotFiltroVillaSchiera()));
    connect(view,SIGNAL(signalFiltroImmobPropri()),this,SLOT(slotFiltroImmobPropri()));

    connect(view,SIGNAL(signalApriInserisci()), this, SLOT(apriInserImmobile()));
    connect(view, SIGNAL(signalVisualizzaImmob()), this, SLOT(slotVisImmob()));
    connect(view, SIGNAL(signalModificaImmob()), this, SLOT(slotModImmob()));

    connect(mod,SIGNAL(signalModificaI()), this,SLOT(slotEseguiMod()));
    connect(view,SIGNAL(esci()),this,SLOT(slotChiudiTutto()));

    connect(ins,SIGNAL(signalInserisciI()), this, SLOT(slotAggiungiImmobile()));
    connect(view,SIGNAL(signalRimuoviImmobile()), this, SLOT(slotRimuoviImmobile()));

    connect(view, SIGNAL(signalCercaCampo()), this, SLOT(slotFiltroParola()));

    view->show();

}


controller::~controller()
{
    if(!(dettagli.empty())){

        vector<VisualizzaDettagli*>::iterator it;
        for(it=dettagli.begin();it!=dettagli.end();it++){

            if(*it){
                delete *it;
                *it=0;
            }

         }
    }

    delete this->m;

}

void controller::errore1()
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Errore");
    msgBox.setText("La superficie edificabile non può essere maggiore di quella totale");
    msgBox.exec();
}

void controller::errore2()
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Errore");
    msgBox.setText("La rata di affitto non può essere superiore al valore dell'immobile");
    msgBox.exec();
}

void controller::errore3()
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Errore");
    msgBox.setText("Devi selezionare il tipo di immobile per effettuare l'inserimento");
    msgBox.exec();
}

void controller::errore4()
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Errore");
    msgBox.setText("Compila tutti i campi per effettuare l'inserimento");
    msgBox.exec();
}

void controller::errore5()
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Errore");
    msgBox.setText("Non puoi inserire una data superiore a quella odierna");
    msgBox.exec();
}
void controller::apriInserImmobile()const
{
   ins->azzeraCampi();
   ins->show();
}

void controller::slotVisImmob()
{

     QList<QListWidgetItem*> list = this->view->getIommobileListWidget()->selectedItems();
     if(list.count() > 0){
         listaImmobiliOggetto* selectedItem = static_cast<listaImmobiliOggetto*>(list.first());
         VisualizzaDettagli* dettagliNew = new VisualizzaDettagli();
         dettagliNew->riempiCampi(selectedItem);
         dettagliNew->show();
         dettagli.push_back(dettagliNew);
     }
}


void controller::slotModImmob()
{
     QList<QListWidgetItem*> list = this->view->getIommobileListWidget()->selectedItems();
     if(list.count() > 0){
         listaImmobiliOggetto* selectedItem = static_cast<listaImmobiliOggetto*>(list.first());
         mod->setImmobileDaModificare(selectedItem->getItem());
         mod->azzeraCampi();
         mod->caricaCampiModifica(selectedItem);
         mod->getTipoImmobile()->setEnabled(false);
         mod->show();
     }
}


void controller::slotEseguiMod()
{
    int indice= mod->getTipoImmobile()->currentIndex();
    immobile*tmp=nullptr;



    QMessageBox msgBox1;
    msgBox1.setWindowTitle("Conferma");
    msgBox1.setText("Immobile modificato con successo!");

    QMessageBox msgBox2;
    msgBox2.setWindowTitle("Errore");

    switch(indice){
        case 0:
        {
          emit errore3();
          return;
        }
        case 1:
        {
            villa*v=new villa();

            v->setAnnoCostr(mod->getAddAnno_costr()->text().toInt());
            v->setBagni(mod->getAddBagni()->text().toInt());
            v->setCamereLetto(mod->getAddCamere()->text().toInt());
            v->setClasseEn(mod->getAddClasse_en()->text().toStdString());
            v->setComune(mod->getAddComune()->text().toStdString());
            v->setContratto(mod->getAddContratto()->text().toInt());
            v->setDestVendita(mod->getAddproprietario_vendita()->text().toStdString());
            v->setDisponib(mod->getAddDisponibilita()->isChecked());
            v->setGiardino(mod->getAddGiardino()->isChecked());
            v->setIndirizzo(mod->getAddIndirizzo()->text().toStdString());
            v->setInVendita(mod->getAddInVendita()->isChecked());
            v->setMansarda(mod->getAddMansardata()->isChecked());
            v->setNote(mod->getAddAltro()->text().toStdString());
            v->setPiani(mod->getAddPiani()->text().toInt());
            v->setPiscina(mod->getAddPiscina()->isChecked());
            v->setPostoAuto(mod->getAddPosto_auto()->text().toInt());
            v->setPrezzoBase(mod->getAddPrezzo_base()->value());
            v->setPrezzoMens(mod->getAddPrezzo_mensile()->value());
            v->setSchiera(mod->getAddSchiera()->text().toInt());
            v->setPosizione(mod->getAddPosizione()->text().toStdString());
            v->setSupTot(mod->getAddSup_totale()->text().toInt());
            v->setTerrazza(mod->getAddTerrazza()->text().toInt());

            if( mod->getAddPrezzo_mensile()->value() > mod->getAddPrezzo_base()->value()){
                   emit errore2();
                   return;
            }
            if(mod->getAddContratto()->text()=="" || mod->getAddPrezzo_mensile()->text()=="") {
                    emit errore4();
                    return;
            }
            if(mod->getAddInVendita()->isChecked() && mod->getAddPrezzo_base()->value()==0 ){
                  emit errore4();
                  return;
             }
            if(mod->getAddAnno_costr()->text().toInt() > (QDate::currentDate().year() )){
                    emit errore5();
                    return;
            }

            if(mod->getAddAnno_costr()->text()=="" ||
               mod->getAddBagni()->text()=="" ||
               mod->getAddCamere()->text()=="" ||
               mod->getAddClasse_en()->text()=="" ||
               mod->getAddComune()->text()=="" ||
               mod->getAddIndirizzo()->text()=="" ||
               mod->getAddPiani()->text()=="" ||
               mod->getAddPosto_auto()->text()=="" ||
               mod->getAddSchiera()->text()=="" ||
               mod->getAddPosizione()->text()=="" ||
               mod->getAddSup_totale()->text()=="" ||
               mod->getAddTerrazza()->text()==""){
                   emit errore4();
                   return;
             }

            tmp=v;
            break;
        }
        case 2:
        {
            appartamento*a=new appartamento();

            a->setAnnoCostr(mod->getAddAnno_costr()->text().toInt());
            a->setAscensore(mod->getAddAscensore()->isChecked());
            a->setAttico(mod->getAddAttico()->isChecked());
            a->setBagni(mod->getAddBagni()->text().toInt());
            a->setCamereLetto(mod->getAddCamere()->text().toInt());
            a->setClasseEn(mod->getAddClasse_en()->text().toStdString());
            a->setComune(mod->getAddComune()->text().toStdString());
            a->setContratto(mod->getAddContratto()->text().toInt());
            a->setDestVendita(mod->getAddproprietario_vendita()->text().toStdString());
            a->setDisponib(mod->getAddDisponibilita()->isChecked());
            a->setIndirizzo(mod->getAddIndirizzo()->text().toStdString());
            a->setInVendita(mod->getAddInVendita()->isChecked());
            a->setNote(mod->getAddAltro()->text().toStdString());
            a->setPiano(mod->getAddPiano()->text().toInt());
            a->setPostoAuto(mod->getAddPosto_auto()->text().toInt());
            a->setPrezzoBase(mod->getAddPrezzo_base()->value());
            a->setPrezzoMens(mod->getAddPrezzo_mensile()->value());
            a->setSpeseCond(mod->getAddSpese_cond()->value());
            a->setSupTot(mod->getAddSup_totale()->text().toInt());
            a->setTerrazza(mod->getAddTerrazza()->text().toInt());

            if(mod->getAddPrezzo_mensile()->value() > mod->getAddPrezzo_base()->value()){
                   emit errore2();
                   return;
            }

            if(mod->getAddContratto()->text()=="" || mod->getAddPrezzo_mensile()->text()==""){
                   emit errore4();
                   return;
            }
            if(mod->getAddInVendita()->isChecked() && mod->getAddPrezzo_base()->value()==0 ){
                   emit errore4();
                   return;
             }
            if(mod->getAddAnno_costr()->text().toInt() > (QDate::currentDate().year() )){
                    emit errore5();
                    return;
            }

            if(mod->getAddAnno_costr()->text()=="" ||
               mod->getAddBagni()->text()=="" ||
               mod->getAddCamere()->text()=="" ||
               mod->getAddClasse_en()->text()=="" ||
               mod->getAddComune()->text()=="" ||
               mod->getAddIndirizzo()->text()=="" ||
               mod->getAddPosto_auto()->text()=="" ||
               mod->getAddSup_totale()->text()=="" ||
               mod->getAddTerrazza()->text()=="" ||
               mod->getAddSpese_cond()->value()==0 ||
               mod->getAddPiano()->text()==""){
                   emit errore4();
                   return;
            }

            tmp=a;
            break;
        }
        case 3:
        {
            terreno*t= new terreno();

            t->setComm(mod->getAddCommerciale()->isChecked());
            t->setComune(mod->getAddComune()->text().toStdString());
            t->setDestVendita(mod->getAddproprietario_vendita()->text().toStdString());
            t->setEdif(mod->getAddEdificabile()->isChecked());
            t->setIndirizzo(mod->getAddIndirizzo()->text().toStdString());
            t->setInVendita(mod->getAddInVendita()->isChecked());
            t->setNote(mod->getAddAltro()->text().toStdString());
            t->setPiant(mod->getAddPiantamento()->isChecked());
            t->setPrezzoBase(mod->getAddPrezzo_base()->value());
            t->setSupTot(mod->getAddSup_totale()->text().toInt());
            t->setSup_Ed(mod->getAddSup_edificab()->text().toInt());

            if(mod->getAddSup_edificab()->text().toInt() > mod->getAddSup_totale()->text().toInt()){
                 emit errore1();
                 return;
            }


            if(mod->getAddComune()->text()=="" ||
               mod->getAddIndirizzo()->text()=="" ||
               mod->getAddSup_edificab()->text()=="" ||
               mod->getAddPrezzo_base()->text()=="" ||
               mod->getAddSup_totale()->text()==""){
                   emit errore4();
                   return;
            }
            tmp=t;
            break;
        }
    }
        if(tmp){
            this->m->aggiornaImmobile(tmp, this->mod->getImmobileDaModificare());
            this->aggiornaListaImmobili(false);
            mod->close();
            msgBox1.exec();
        }else{
            msgBox2.setText("Errore");
            msgBox2.exec();
        }
}

void controller::slotRimuoviImmobile()
{
    listaimmobili*l=view->getIommobileListWidget();
    listaImmobiliOggetto*ll= l->currentItem();
    if(ll){
        immobile*i= ll->getItem();
        l->removeImmobile(ll);
        m->rimuoviImmobile(i);
        QMessageBox msgBox;
        msgBox.setWindowTitle("Conferma");
        msgBox.setText("Immobile eliminato");
        msgBox.exec();
    }
}

void controller::slotFiltroParola()
{
    QString parola= view->getCampoCerca();
    m->filtroParolaCercata(parola);
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroVilla()
{
    m->filtroVille();
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroAppartamento()
{
    m->filtroAppartamenti();
     this->aggiornaListaImmobili(true);
}

void controller::slotFiltroTerreno()
{
    m->filtroTerreni();
     this->aggiornaListaImmobili(true);
}

void controller::slotFiltroVillaSingola()
{
    m->filtroVilleSingole();
     this->aggiornaListaImmobili(true);
}

void controller::slotFiltroTerrenoEdificabile()
{
    m->filtroTerreniEdificabili();
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroTerrenoAgricolo()
{
    m->filtroTerreniAgricoli();
     this->aggiornaListaImmobili(true);
}

void controller::slotFiltroAffittabile()
{
    m->filtroAffittabile();
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroInVendita()
{
    m->filtroInVendita();
    this->aggiornaListaImmobili(true);
}

void controller::slotRimuoviFiltro(){
    this->aggiornaListaImmobili(false);
}

void controller::slotFiltroAppSpese()
{
    m->filtroAppSpese();
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroVillaSchiera()
{
    m->filtroVilleSchiera();
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroImmobPropri()
{
    m->filtroImmPropri();
    this->aggiornaListaImmobili(true);
}

void controller::slotFiltroAppAttico()
{
    m->filtroAppAttico();
    this->aggiornaListaImmobili(true);
}

void controller::slotAggiungiImmobile()
{

    int indice= ins->getTipoImmobile()->currentIndex();
    immobile*daInserire=nullptr;

    QMessageBox msgBox1;
    msgBox1.setWindowTitle("Conferma");
    msgBox1.setText("Immobile inserito");

    QMessageBox msgBox2;
    msgBox2.setWindowTitle("Errore");

    switch(indice){
        case 0:
        {
          emit errore3();
          return;
        }
        case 1:
        {
            villa*v=new villa();

            v->setAnnoCostr(ins->getAddAnno_costr()->text().toInt());
            v->setBagni(ins->getAddBagni()->text().toInt());
            v->setCamereLetto(ins->getAddCamere()->text().toInt());
            v->setClasseEn(ins->getAddClasse_en()->text().toStdString());
            v->setComune(ins->getAddComune()->text().toStdString());
            v->setContratto(ins->getAddContratto()->text().toInt());
            v->setDestVendita(ins->getAddproprietario_vendita()->text().toStdString());
            v->setDisponib(ins->getAddDisponibilita()->isChecked());
            v->setGiardino(ins->getAddGiardino()->isChecked());
            v->setIndirizzo(ins->getAddIndirizzo()->text().toStdString());
            v->setInVendita(ins->getAddInVendita()->isChecked());
            v->setMansarda(ins->getAddMansardata()->isChecked());
            v->setNote(ins->getAddAltro()->text().toStdString());
            v->setPiani(ins->getAddPiani()->text().toInt());
            v->setPiscina(ins->getAddPiscina()->isChecked());
            v->setPostoAuto(ins->getAddPosto_auto()->text().toInt());
            v->setPrezzoBase(ins->getAddPrezzo_base()->value());
            v->setPrezzoMens(ins->getAddPrezzo_mensile()->value());
            v->setSchiera(ins->getAddSchiera()->text().toInt());
            v->setPosizione(ins->getAddPosizione()->text().toStdString());
            v->setSupTot(ins->getAddSup_totale()->text().toInt());
            v->setTerrazza(ins->getAddTerrazza()->text().toInt());

            if(ins->getAddPrezzo_mensile()->value() > ins->getAddPrezzo_base()->value()){
                   emit errore2();
                   return;
            }
            if(ins->getAddContratto()->text()=="" || ins->getAddPrezzo_mensile()->text()==""){
                    emit errore4();
                    return;
            }
            if(ins->getAddInVendita()->isChecked() && ins->getAddPrezzo_base()->value()==0 ){
                  emit errore4();
                  return;
             }
            if(ins->getAddAnno_costr()->text().toInt() > (QDate::currentDate().year() )){
                    emit errore5();
                    return;
            }


            if(ins->getAddAnno_costr()->text()=="" ||
               ins->getAddBagni()->text()=="" ||
               ins->getAddCamere()->text()=="" ||
               ins->getAddClasse_en()->text()=="" ||
               ins->getAddComune()->text()=="" ||
               ins->getAddIndirizzo()->text()=="" ||
               ins->getAddPiani()->text()=="" ||
               ins->getAddPosto_auto()->text()=="" ||
               ins->getAddSchiera()->text()=="" ||
               ins->getAddPosizione()->text()=="" ||
               ins->getAddSup_totale()->text()=="" ||
               ins->getAddTerrazza()->text()==""){
                   emit errore4();
                   return;
             }

            daInserire=v;
            break;
        }
        case 2:
        {
            appartamento*a=new appartamento();

            a->setAnnoCostr(ins->getAddAnno_costr()->text().toInt());
            a->setAscensore(ins->getAddAscensore()->isChecked());
            a->setAttico(ins->getAddAttico()->isChecked());
            a->setBagni(ins->getAddBagni()->text().toInt());
            a->setCamereLetto(ins->getAddCamere()->text().toInt());
            a->setClasseEn(ins->getAddClasse_en()->text().toStdString());
            a->setComune(ins->getAddComune()->text().toStdString());
            a->setContratto(ins->getAddContratto()->text().toInt());
            a->setDestVendita(ins->getAddproprietario_vendita()->text().toStdString());
            a->setDisponib(ins->getAddDisponibilita()->isChecked());
            a->setIndirizzo(ins->getAddIndirizzo()->text().toStdString());
            a->setInVendita(ins->getAddInVendita()->isChecked());
            a->setNote(ins->getAddAltro()->text().toStdString());
            a->setPiano(ins->getAddPiano()->text().toInt());
            a->setPostoAuto(ins->getAddPosto_auto()->text().toInt());
            a->setPrezzoBase(ins->getAddPrezzo_base()->value());
            a->setPrezzoMens(ins->getAddPrezzo_mensile()->value());
            a->setSpeseCond(ins->getAddSpese_cond()->value());
            a->setSupTot(ins->getAddSup_totale()->text().toInt());
            a->setTerrazza(ins->getAddTerrazza()->text().toInt());

            if(ins->getAddPrezzo_mensile()->value() > ins->getAddPrezzo_base()->value()){
                   emit errore2();
                   return;
            }

            if(ins->getAddContratto()->text()=="" || ins->getAddPrezzo_mensile()->text()==""){
                   emit errore4();
                   return;
            }
            if(ins->getAddInVendita()->isChecked() && ins->getAddPrezzo_base()->value()==0 ){
                   emit errore4();
                   return;
             }
            if(ins->getAddAnno_costr()->text().toInt() > (QDate::currentDate().year() )){
                    emit errore5();
                    return;
            }


            if(ins->getAddAnno_costr()->text()=="" ||
               ins->getAddBagni()->text()=="" ||
               ins->getAddCamere()->text()=="" ||
               ins->getAddClasse_en()->text()=="" ||
               ins->getAddComune()->text()=="" ||
               ins->getAddIndirizzo()->text()=="" ||
               ins->getAddPosto_auto()->text()=="" ||
               ins->getAddSup_totale()->text()=="" ||
               ins->getAddTerrazza()->text()=="" ||
               ins->getAddSpese_cond()->value()==0 ||
               ins->getAddPiano()->text()==""){
                   emit errore4();
                   return;
            }
            daInserire=a;
            break;
        }
        case 3:
        {
            terreno*t= new terreno();

            t->setComm(ins->getAddCommerciale()->isChecked());
            t->setComune(ins->getAddComune()->text().toStdString());
            t->setDestVendita(ins->getAddproprietario_vendita()->text().toStdString());
            t->setEdif(ins->getAddEdificabile()->isChecked());
            t->setIndirizzo(ins->getAddIndirizzo()->text().toStdString());
            t->setInVendita(ins->getAddInVendita()->isChecked());
            t->setNote(ins->getAddAltro()->text().toStdString());
            t->setPiant(ins->getAddPiantamento()->isChecked());
            t->setPrezzoBase(ins->getAddPrezzo_base()->value());
            t->setSupTot(ins->getAddSup_totale()->text().toInt());
            t->setSup_Ed(ins->getAddSup_edificab()->text().toInt());

            if(ins->getAddSup_edificab()->text().toInt() > ins->getAddSup_totale()->text().toInt()){
                 emit errore1();
                 return;
            }

            if(ins->getAddComune()->text()=="" ||
               ins->getAddIndirizzo()->text()=="" ||
               ins->getAddSup_edificab()->text()=="" ||
               ins->getAddPrezzo_base()->value()==0 ||
               ins->getAddSup_totale()->text()==""){
                   emit errore4();
                   return;
            }

            daInserire=t;
            break;
    }

    }
    if(daInserire!=nullptr){
        m->riempiDatabase(daInserire);
        this->aggiornaListaImmobili(false);
        ins->close();
        msgBox1.exec();
    }else{
        msgBox2.setText("Errore");
        msgBox2.exec();
    }
}

void controller::slotChiudiTutto()
{
    if(this->ins!=nullptr && this->ins->isVisible()){
        this->ins->close();
    }
    if(this->mod!=nullptr && this->mod->isVisible()){
        this->mod->close();
    }

    if(!(dettagli.empty())){
        vector<VisualizzaDettagli*>::iterator it;
        for(it=dettagli.begin();it!=dettagli.end();it++){

            if((*it) != NULL && (*it)->isVisible()){
                (*it)->close();
                *it = 0;
            }
         }
    }

    this->view->close();

}


void controller::aggiornaListaImmobili(bool useFiltered)
{
    view->getIommobileListWidget()->clear();
    database<immobile*>::iteratore it;

    database<immobile*>* listaImmobili;
    if(!useFiltered){
        listaImmobili = this->m->getListaImmobili();
    }
    else{
        listaImmobili = this->m->getListaImmobiliFiltered();
    }

    if(!listaImmobili->empty()){
        for(it=listaImmobili->begin();it!=listaImmobili->end();++it){
            if((*it) != nullptr){
                view->getIommobileListWidget()->addImmobile((*it));
            }
         }
    }
}

