#ifndef COMBOIMMOBILE_H
#define COMBOIMMOBILE_H

#include <QComboBox>
#include <QWidget>

class ComboImmobile : public QComboBox
{
    Q_OBJECT
public:
    ComboImmobile(QWidget * = nullptr);

};
#endif // COMBOIMMOBILE_H
