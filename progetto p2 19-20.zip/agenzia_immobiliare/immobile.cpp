#include "immobile.h"

using namespace std;

immobile::immobile(string i, int s_t, string a, string co) :
    indirizzo(i), superficie_tot(s_t), altro(a), comune(co) {}

string immobile::getIndirizzo() const
{
    return indirizzo;
}

int immobile::getSup_tot() const
{
    return superficie_tot;
}


string immobile::getAltro() const
{
    return altro;
}

string immobile::getComune() const
{
    return comune;
}

void immobile::setIndirizzo(string ind)
{
    indirizzo=ind;
}

void immobile::setSupTot(int supT)
{
    superficie_tot=supT;
}

void immobile::setNote(string note)
{
    altro=note;
}

void immobile::setComune(string dove)
{
    comune=dove;
}


string immobile::getInfo() const {

    string str = "";
    return str.append("Tipo: "+ this->getTipo())
            .append(" - Comune: " +this->getComune())
            .append(" - Indirizzo: "+ this->getIndirizzo())
            .append(" - Superficie Tot: " + std::to_string(this->getSup_tot()))
            .append(" - Prezzo: "+ std::to_string(this->prezzoFinale()).append(" €"));

}





