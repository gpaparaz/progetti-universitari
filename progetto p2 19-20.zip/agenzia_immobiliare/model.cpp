#include "model.h"

model::model() : lista_immobili(new database<immobile*>()), dati_filtrati(new database<immobile*>()) {}


model::~model(){

    lista_immobili->svuotaDatabase();
    dati_filtrati->svuotaDatabase();

    delete lista_immobili;
    delete dati_filtrati;

}


void model::riempiDatabase(immobile *i)
{
    lista_immobili->pushback(i);
}

void model::rimuoviImmobile(immobile*i)
{
    if(!lista_immobili->empty())
        lista_immobili->remove(i);
    if(!dati_filtrati->empty())
        dati_filtrati->remove(i);
}

//==========FILTRI

void model::resetFiltro()
{
    dati_filtrati->svuotaDatabase();
}

void model::filtroVille()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        villa* v= dynamic_cast<villa*>(i);
        if(v){
            dati_filtrati->pushback(v);
        }
    }
}

void model::filtroAppartamenti(){
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        appartamento* a= dynamic_cast<appartamento*>(i);
        if(a){
            dati_filtrati->pushback(a);
        }
    }
}

void model::filtroTerreni(){
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        terreno* t= dynamic_cast<terreno*>(i);
        if(t){
            dati_filtrati->pushback(t);
        }
    }
}

void model::filtroVilleSingole(){
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        villa* v= dynamic_cast<villa*>(i);
        if(v && v->getSchiera()==0){
            dati_filtrati->pushback(v);
        }
    }
}

void model::filtroTerreniAgricoli(){
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        terreno* t= dynamic_cast<terreno*>(i);
        if(t && t->getPiant()==true){
            dati_filtrati->pushback(t);
        }
    }
}

void model::filtroAffittabile()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        affitto*a=dynamic_cast<affitto*>(i);
        if( a && a->getDisponib()==true){
            dati_filtrati->pushback(a);
        }
    }
}

void model::filtroInVendita()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        vendita*v=dynamic_cast<vendita*>(i);
        if( v && v->getVendesi()==true){
            dati_filtrati->pushback(v);
        }
    }
}

void model::filtroVilleSchiera()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        villa*v=dynamic_cast<villa*>(i);
        if(v && v->getSchiera() != 0){
            dati_filtrati->pushback(v);
        }
    }
}

void model::filtroAppSpese()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        appartamento*a=dynamic_cast<appartamento*>(i);
        if(a && a->getSpese() < 3000){
            dati_filtrati->pushback(a);
        }
    }
}

void model::filtroAppAttico()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        appartamento*a=dynamic_cast<appartamento*>(i);
        if(a && a->getAttico()==true){
            dati_filtrati->pushback(a);
        }
    }
}

void model::filtroImmPropri()
{
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        vendita*v=dynamic_cast<vendita*>(i);
        if(v && (v->getproprietario()=="Agenzia" || v->getproprietario()=="PaGi" || v->getproprietario()=="Pagi")){
            dati_filtrati->pushback(v);
        }
    }
}

void model::filtroParolaCercata(QString parola)
{
    dati_filtrati->svuotaDatabase();
    std::string campo= parola.toStdString();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;

        if(i && i->getComune()==campo)
                dati_filtrati->pushback(i);
        }        

}


void model::filtroTerreniEdificabili(){
    dati_filtrati->svuotaDatabase();
    for(auto it= lista_immobili->begin(); it!=lista_immobili->end(); ++it){
        immobile* i= *it;
        terreno* t= dynamic_cast<terreno*>(i);
        if(t && t->getEdif()==true){
            dati_filtrati->pushback(t);
        }
    }
}


database<immobile*>* model::getListaImmobili(){
    return this->lista_immobili;
}
database<immobile*>* model::getListaImmobiliFiltered(){
    return this->dati_filtrati;
}


void model::aggiornaImmobile(immobile* imm, immobile* immobileDaModificare){

    lista_immobili->sostituisciNodo(immobileDaModificare, imm);

}
