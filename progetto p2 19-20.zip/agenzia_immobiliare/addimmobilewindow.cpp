#include "addimmobilewindow.h"

addimmobilewindow::addimmobilewindow(QWidget *parent) : QWidget(parent),tipo_immobile(new ComboImmobile(this)),  info_vendita (new QGroupBox("Dettagli Vendita",this)), info_affitto (new QGroupBox("Dettagli Affitto",this)), info_generali (new QGroupBox("Generali",this)), info_edificio (new QGroupBox("Edificio",this)),
    info_villa(new QGroupBox("Specifiche Villa",this)), info_appart (new QGroupBox("Specifiche Appartamento",this)), info_terreno (new QGroupBox("Terreno",this))
{
    setWindowTitle("Aggiungi Immobile");
    setWindowIcon(QIcon(":pagi_ico.jpg"));
    finestra_add_base= new QHBoxLayout(this);
    setMinimumSize(700,700);
    setLayout(finestra_add_base);

    layout_sx= new QVBoxLayout();
    layout_vendita_dx= new QVBoxLayout();


    QLabel*intestazione=new QLabel("Seleziona il tipo di immobile:");
    layout_sx->addWidget(intestazione);
    layout_sx->addWidget(tipo_immobile);
    tipo_immobile->setMinimumHeight(50);
    finestra_add_base->addLayout(layout_sx);
    finestra_add_base->addLayout(layout_vendita_dx);


//Generali
     QFormLayout *generale_flayout = new QFormLayout();
     indirizzo = new QLineEdit();
     indirizzo->setPlaceholderText("es. Via San Carlo 5");
     generale_flayout->addRow(tr("&Indirizzo:"), indirizzo);

     comune = new QLineEdit();
     comune->setPlaceholderText("es. Padova");
     generale_flayout->addRow(tr("&Comune:"), comune);

     sup_totale= new QLineEdit();
     sup_totale->setValidator(new QRegExpValidator(QRegExp("[1-9][0-9][0-9][0-9][0-9][0-9]")));
     generale_flayout->addRow(tr("&Superficie Totale:"), sup_totale);

     altro = new QLineEdit();
     altro->setPlaceholderText("es. Da ristrutturare");
     generale_flayout->addRow(tr("&Note:"), altro);

     info_generali->setLayout(generale_flayout);
     layout_sx->addWidget(info_generali);


//Box info edificio
     QFormLayout *edificio_flayout = new QFormLayout();

     posto_auto= new QLineEdit();
     posto_auto->setValidator(new QRegExpValidator(QRegExp("[0-9][0-9]")));
     edificio_flayout->addRow(tr("&Posti Auto:"), posto_auto);

     bagni= new QLineEdit();
     bagni->setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]")));
     edificio_flayout->addRow(tr("&Nr. di Bagni:"), bagni);

     camere= new QLineEdit();
     camere->setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]")));
     edificio_flayout->addRow(tr("&Nr. di Camere:"), camere);

     terrazza= new QLineEdit();
     terrazza->setValidator(new QRegExpValidator(QRegExp("[0-9]")));
     edificio_flayout->addRow(tr("&Terrazzato:"), terrazza);

     classe_en= new QLineEdit();
     classe_en->setValidator(new QRegExpValidator(QRegExp("[A-G][+]")));
     edificio_flayout->addRow(tr("&Classe Energetica:"), classe_en);

     anno_costr= new QLineEdit();
     anno_costr->setValidator(new QRegExpValidator(QRegExp("[1-2][0-9][0-9][0-9]")));
     edificio_flayout->addRow(tr("&Anno di Costruzione:"), anno_costr);

     info_edificio->setLayout(edificio_flayout);
     layout_sx->addWidget(info_edificio);


//Box info Villa
     QFormLayout *villa_flayout = new QFormLayout();

     piani= new QLineEdit();
     piani->setValidator(new QRegExpValidator(QRegExp("[0-9]")));
     villa_flayout->addRow(tr("&Nr. di Piani:"), piani);

     schiera= new QLineEdit();
     schiera->setValidator(new QRegExpValidator(QRegExp("[0-9]")));
     villa_flayout->addRow(tr("&Nr. di Case a Schiera:"), schiera);

     posizione= new QLineEdit();
     posizione->setPlaceholderText("es. Centrale o Laterale");
     villa_flayout->addRow(tr("&Posizione schiera"), posizione);

     mansardata= new QCheckBox();
     villa_flayout->addRow(tr("&Mansardata:"), mansardata);

     giardino= new QCheckBox();
     villa_flayout->addRow(tr("&Con Giardino:"), giardino);

     piscina= new QCheckBox();
     villa_flayout->addRow(tr("&Con Piscina:"), piscina);

     info_villa->setLayout(villa_flayout);

     QHBoxLayout *tipo_edifici= new QHBoxLayout();
     tipo_edifici->addWidget(info_villa);
     layout_sx->addLayout(tipo_edifici);


//Box info appartamento
     QFormLayout *appartamento_flayout = new QFormLayout();

     piano= new QLineEdit();
     piano->setValidator(new QRegExpValidator(QRegExp("[0-9][0-9][0-9]")));
     appartamento_flayout->addRow(tr("&Posizionato al Piano:"), piano);

     spese_cond= new QDoubleSpinBox();
     spese_cond->setMaximum(10000);
     appartamento_flayout->addRow(tr("&Spese Condominiali annue:"), spese_cond);

     ascensore= new QCheckBox();
     appartamento_flayout->addRow(tr("&Ascensore:"), ascensore);

     attico= new QCheckBox();
     appartamento_flayout->addRow(tr("&Attico:"), attico);

     info_appart->setLayout(appartamento_flayout);
     tipo_edifici->addWidget(info_appart);


//Box info affitto
     QFormLayout *affitto_flayout = new QFormLayout();

     prezzo_mensile= new QDoubleSpinBox();
     prezzo_mensile->setMaximum(90000);
     affitto_flayout->addRow(tr("&Rata dell'affitto:"), prezzo_mensile);

     contratto= new QLineEdit();
     contratto->setValidator(new QRegExpValidator(QRegExp("[1-9][0-9][0-9]")));
     affitto_flayout->addRow(tr("&Durata Contratto in mesi:"), contratto);

     disponibile_affitto= new QCheckBox();
     affitto_flayout->addRow(tr("&Attualmente occupata:"), disponibile_affitto);

     info_affitto->setLayout(affitto_flayout);
     layout_vendita_dx->addWidget(info_affitto);


//Box Info vendita
     QFormLayout *vendita_flayout = new QFormLayout();

     prezzo_base= new QDoubleSpinBox();
     prezzo_base->setMaximum(99000000);
     vendita_flayout->addRow(tr("&Prezzo Base"), prezzo_base);

     proprietario_vendita= new QLineEdit();
     proprietario_vendita->setPlaceholderText("es. Agenzia");
     vendita_flayout->addRow(tr("&Attuale proprietario: "), proprietario_vendita);

     in_vendita= new QCheckBox();
     vendita_flayout->addRow(tr("&Attualmente in vendita: "), in_vendita);

     info_vendita->setLayout(vendita_flayout);
     layout_vendita_dx->addWidget(info_vendita);


//Box info terreno
     QFormLayout *terreno_flayout = new QFormLayout();

     sup_edificab= new QLineEdit();
     sup_edificab->setValidator(new QRegExpValidator(QRegExp("[0-9][0-9][0-9][0-9]")));
     terreno_flayout->addRow(tr("&Superficie Edificabile:"), sup_edificab);

     edificabile= new QCheckBox();
     terreno_flayout->addRow(tr("&Edificabile:"), edificabile);

     piantamento= new QCheckBox();
     terreno_flayout->addRow(tr("&Per Piantamento"), piantamento);

     commerciale= new QCheckBox();
     terreno_flayout->addRow(tr("&Tipo Commerciale"), commerciale);

     info_terreno->setLayout(terreno_flayout);
     layout_vendita_dx->addWidget(info_terreno);


     aggiungi= new QPushButton("Inserisci", this);
     aggiungi->setEnabled(false);
     annulla= new QPushButton("Annulla", this);

     QHBoxLayout *bottoni_layout= new QHBoxLayout();
     bottoni_layout->addWidget(aggiungi);
     bottoni_layout->addWidget(annulla);

     layout_vendita_dx->addLayout(bottoni_layout);

//disabilita groupbox
     info_vendita->setEnabled(false);
     info_affitto->setEnabled(false);
     sDisabilitaCQ(0);


//CONNECT
     connect(tipo_immobile, SIGNAL(activated(int)), this, SLOT(sDisabilitaCQ(int)));
     connect(annulla, SIGNAL(clicked()), this, SLOT(close()));
     connect(aggiungi, SIGNAL(clicked()), this, SLOT(inserisci()));
     connect(edificabile, SIGNAL(clicked()), this, SLOT(slotSeEdif()));
     connect(piantamento, SIGNAL(clicked()), this, SLOT(slotSePiant()));
     connect(commerciale, SIGNAL(clicked()), this, SLOT(slotSeComm()));
}


void addimmobilewindow::inserisci(){
    emit signalInserisciI();
}


void addimmobilewindow::sDisabilitaCQ(int indice)const
{
    switch (indice) {
    case 1://villa

        info_generali->setEnabled(true);
        info_edificio->setEnabled(true);
        info_villa->setEnabled(true);

        info_appart->setEnabled(false);
        info_terreno->setEnabled(false);
        aggiungi->setEnabled(true);
        info_vendita->setEnabled(true);
        info_affitto->setEnabled(true);

        break;

    case 2://appartamento
        info_generali->setEnabled(true);
        info_edificio->setEnabled(true);
        info_appart->setEnabled(true);

        info_villa->setEnabled(false);
        info_terreno->setEnabled(false);
        aggiungi->setEnabled(true);
        info_vendita->setEnabled(true);
        info_affitto->setEnabled(true);

        break;

    case 3://terreno
        info_generali->setEnabled(true);
        info_terreno->setEnabled(true);

        info_edificio->setEnabled(false);
        info_appart->setEnabled(false);
        info_villa->setEnabled(false);
        aggiungi->setEnabled(true);
        info_affitto->setEnabled(false);
        info_vendita->setEnabled(true);

        break;

    case 0:
        info_generali->setEnabled(true);

        info_edificio->setEnabled(false);
        info_villa->setEnabled(false);
        info_appart->setEnabled(false);
        info_terreno->setEnabled(false);
        aggiungi->setEnabled(false);


        break;
    }
}

void addimmobilewindow::slotSeEdif(){
    if(edificabile->isChecked()==true){
        piantamento->setChecked(false);
    }
}

void addimmobilewindow::slotSePiant(){
    if(piantamento->isChecked()==true){
        edificabile->setChecked(false);
        commerciale->setChecked(false);
    }
}

void addimmobilewindow::slotSeComm(){
    if(commerciale->isChecked()==true){
        piantamento->setChecked(false);
    }
}


QDoubleSpinBox * addimmobilewindow::getAddPrezzo_mensile()const{
    return prezzo_mensile;
}
QLineEdit * addimmobilewindow::getAddContratto()const{
    return contratto;
}

QDoubleSpinBox * addimmobilewindow::getAddPrezzo_base()const{
    return prezzo_base;
}
QLineEdit * addimmobilewindow::getAddproprietario_vendita()const{
    return proprietario_vendita;
}
QLineEdit * addimmobilewindow::getAddIndirizzo()const{
    return indirizzo;
}
QLineEdit * addimmobilewindow::getAddComune()const{
    return comune;
}
QLineEdit * addimmobilewindow::getAddSup_totale()const{
    return sup_totale;
}
QLineEdit * addimmobilewindow::getAddAltro()const{
    return altro;
}
QLineEdit * addimmobilewindow::getAddPosto_auto()const{
    return posto_auto;
}
QLineEdit * addimmobilewindow::getAddBagni()const{
    return bagni;
}
QLineEdit * addimmobilewindow::getAddCamere()const{
    return camere;
}
QLineEdit * addimmobilewindow::getAddTerrazza()const{
    return terrazza;
}
QLineEdit * addimmobilewindow::getAddClasse_en()const{
    return classe_en;
}
QLineEdit * addimmobilewindow::getAddAnno_costr()const{
    return anno_costr;
}
QLineEdit * addimmobilewindow::getAddPiani()const{
    return piani;
}
QLineEdit * addimmobilewindow::getAddSchiera()const{
    return schiera;
}
QLineEdit * addimmobilewindow::getAddPosizione()const{
    return posizione;
}
QLineEdit * addimmobilewindow::getAddPiano()const{
    return piano;
}
QDoubleSpinBox * addimmobilewindow::getAddSpese_cond()const{
    return spese_cond;
}
QLineEdit * addimmobilewindow::getAddSup_edificab()const{
    return sup_edificab;
}

QCheckBox * addimmobilewindow::getAddDisponibilita()const{
    return disponibile_affitto;
}

QCheckBox * addimmobilewindow::getAddInVendita()const{
    return in_vendita;
}
QCheckBox * addimmobilewindow::getAddMansardata()const{
    return mansardata;
}
QCheckBox * addimmobilewindow::getAddPiscina()const{
    return piscina;
}
QCheckBox * addimmobilewindow::getAddGiardino()const{
    return giardino;
}
QCheckBox * addimmobilewindow::getAddAscensore()const{
    return ascensore;
}
QCheckBox * addimmobilewindow::getAddAttico()const{
    return attico;
}
QCheckBox * addimmobilewindow::getAddEdificabile()const{
    return edificabile;
}
QCheckBox * addimmobilewindow::getAddPiantamento()const{
    return piantamento;
}
QCheckBox * addimmobilewindow::getAddCommerciale()const{
    return commerciale;
}

QPushButton *addimmobilewindow::getAggiungiImm() const
{
    return aggiungi;
}

QPushButton *addimmobilewindow::getAnnulla() const
{
    return annulla;
}

ComboImmobile *addimmobilewindow::getTipoImmobile() const
{
    return tipo_immobile;
}

void addimmobilewindow::azzeraCampi() const
{
     info_vendita->setEnabled(false);
     info_affitto->setEnabled(false);
     tipo_immobile->setCurrentIndex(0);
     sDisabilitaCQ(0);
     prezzo_mensile->setValue(0);
     contratto->setText("");
     comune->setText("");
     prezzo_base->setValue(0);
     proprietario_vendita->setText("");
     indirizzo->setText("");
     sup_totale->setText("");
     altro->setText("");
     posto_auto->setText("");
     bagni->setText("");
     camere->setText("");
     terrazza->setText("");
     classe_en->setText("");
     anno_costr->setText("");
     piani->setText("");
     schiera->setText("");
     posizione->setText("");
     piano->setText("");
     spese_cond->setValue(0);
     sup_edificab->setText("");
     in_vendita->setChecked(false);
     disponibile_affitto->setChecked(false);
     mansardata->setChecked(false);
     piscina->setChecked(false);
     giardino->setChecked(false);
     ascensore->setChecked(false);
     attico->setChecked(false);
     edificabile->setChecked(false);
     piantamento->setChecked(false);
     commerciale->setChecked(false);
}

