#include "villa.h"


villa::villa( string i, int s_t, string a, string co,
              double p_b, string dest, bool vend,
              double p_m, int d_c, bool disp,
              int p_a, int b, int c_l, int t, string c_e, int a_c,
               int pian, bool m, bool sw, bool garden, int sch, string pos) :
   edifici(i, s_t, a, co, p_b, dest, vend, p_m, d_c, disp, p_a, b, c_l, t, c_e, a_c),
    piani(pian), mansarda(m), piscina(sw), giardino(garden), schiera(sch), posizione(pos) {}



string villa::getTipo() const{

    return "Villa";
}
double villa::anticipo() const
{
    return prezzoFinale()*0.06;
}

double villa::prezzoFinale() const
{
    double prezzoF= getPrezzo_base();

    if(mansarda==false)
        prezzoF -= (prezzoF *0.02);
    if(piscina==true)
        prezzoF += (prezzoF * 0.05);
    if(giardino==true)
        prezzoF += (prezzoF * 0.03);
    if(schiera > 0)
        prezzoF -= (prezzoF * 0.02);
    if(posizione== "centrale")
        prezzoF -= (prezzoF * 0.01);
    if(piani>1)
        prezzoF += (prezzoF * 0.02);
    if(getSup_tot() > 500)
        prezzoF += (prezzoF * 0.15);


    return prezzoF;
}

double villa::commissione_affitto() const
{
    return getPrezzoMens()* 0.20;
}

double villa::commissione_guadagno() const
{
    if(getproprietario()=="Agenzia" || getproprietario()=="Pagi" || getproprietario()=="PaGi"){
        return prezzoFinale();
    }
    else{
        return prezzoFinale()*0.25;
    }
}

villa *villa::clone() const
{
    return new villa(*this);
}

int villa::getPiani() const
{
    return piani;
}

bool villa::getMansarda() const
{
    return mansarda;
}

bool villa::getPiscina() const
{
    return piscina;
}

bool villa::getGiardino() const
{
    return giardino;
}

int villa::getSchiera() const
{
    return schiera;
}

string villa::getPosizione() const
{
    return posizione;
}

void villa::setPiani(int floors)
{
    piani=floors;
}

void villa::setMansarda(bool attic)
{
    mansarda=attic;
}

void villa::setPiscina(bool swim)
{
    piscina=swim;
}

void villa::setGiardino(bool garden)
{
    giardino=garden;
}

void villa::setSchiera(int schi)
{
    schiera=schi;
}

void villa::setPosizione(string position)
{
    posizione=position;
}
