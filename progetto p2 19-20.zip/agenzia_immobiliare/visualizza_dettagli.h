#ifndef VISUALIZZA_DETTAGLI_H
#define VISUALIZZA_DETTAGLI_H
#include <mainwindow.h>
#include <database.h>
#include <model.h>
#include <immobile.h>
#include <QWidget>
#include <QStringList>
#include<QIcon>

class VisualizzaDettagli: public QWidget
{
public:
    VisualizzaDettagli( QWidget *parent=nullptr);
    void riempiCampi(listaImmobiliOggetto* imm);

private:
    QHBoxLayout *finestra_vis_base;
    QVBoxLayout *layout_vis_sx, *layout_vendita_vis_dx;
    QGroupBox *info_vendita,  *info_affitto, *info_generali, *info_edificio, *info_villa, *info_appart, *info_terreno;
    QLabel *immobile_tipo,*prezzo_mensile, *contratto, *disponibilita,
    *proprietario_vendita, *inVendita,
    *indirizzo, *sup_totale, *altro, *affittabile, *comune,
    *posto_auto, *bagni, *camere, *terrazza, *classe_en, *anno_costr,
    *piani, *mansardata, *piscina, *giardino, *schiera,*posizione,
    *ascensore, *piano, *spese_cond, *attico,
    *edificabile, *piantamento, *sup_edificab, *commerciale, *prezzoFinale,*commissioni_affit, *anticipo, *guadagno;
    QPushButton *chiudi;

};

#endif // VISUALIZZA_DETTAGLI_H
