#ifndef LISTAIMMOBILI_H
#define LISTAIMMOBILI_H

#include<database.h>
#include<listaimmobilioggetto.h>
#include<QWidget>
#include<QListWidget>



class listaimmobili : public QListWidget
{

private:
     Q_OBJECT
    QWidget* parent;

public:
    listaimmobili( QWidget * =nullptr);

    void addImmobile(immobile*);
    listaImmobiliOggetto* currentItem() const;

    void removeImmobile(listaImmobiliOggetto*);

};

#endif // LISTAIMMOBILI_H
