#ifndef model_H
#define model_H

#include <affitto.h>
#include <vendita.h>
#include <immobile.h>
#include <edifici.h>
#include <terreno.h>
#include <appartamento.h>
#include <villa.h>
#include <database.h>
#include <string>

#include <QObject>
#include <QStringList>
#include <QString>


class model
{
private:
    database<immobile*> *lista_immobili;
    database<immobile*> *dati_filtrati;

public:
    model();
    ~model();

    void riempiDatabase(immobile*);

    void rimuoviImmobile(immobile*);

    void resetFiltro();
    void filtroVille();
    void filtroAppartamenti();
    void filtroTerreni();
    void filtroVilleSingole();
    void filtroTerreniEdificabili();
    void filtroTerreniAgricoli();
    void filtroAffittabile();
    void filtroInVendita();
    void filtroVilleSchiera();
    void filtroAppSpese();
    void filtroAppAttico();
    void filtroImmPropri();

    void filtroParolaCercata(QString );

    void aggiornaImmobile(immobile* imm, immobile* immobileDaModificare);

    database<immobile*>* getListaImmobili();
    database<immobile*>* getListaImmobiliFiltered();

};

#endif // model_H
