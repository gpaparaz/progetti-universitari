#ifndef AFFITTO_H
#define AFFITTO_H
#include <string>
#include "immobile.h"
using std::string;

class affitto: virtual public immobile
{
private:
    double prezzo_mensile;
    int durata_contratto;
    bool disponibilita; //se attualmente è libero, quindi disponibile

public:
    affitto(string i="", int s_t=0, string a="", string co="",
            double p_m=0, int d_c=0, bool disp=false);

    virtual ~affitto() = default;

    double getPrezzoMens() const;
    int getContratto() const;
    bool getDisponib() const;

    void setPrezzoMens(double);
    void setContratto(int);
    void setDisponib(bool);
    void setAffittabile(bool);

    virtual double commissione_affitto() const=0;

};

#endif // AFFITTO_H
