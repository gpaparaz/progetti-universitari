#ifndef DATABASE_H
#define DATABASE_H

template<class T>
class database
{
private:
    class nodo {
        friend class database<T>;
      public:
        T info;
        nodo *next;
        nodo(const T& t, nodo* n=nullptr);
        nodo(const nodo&);

        void elimina();
      };

    nodo*first; nodo*last;
    unsigned int conta_nodi;

    static nodo*copia(nodo*, nodo*&);
    void aumenta_conta();


public:

    database();
    database(const database&);
    ~database();

    database& operator=(const database&);

    class iteratore{
        friend class database<T>;
    private:
        nodo*ptr;
    public:
        iteratore();
        iteratore(nodo*);
        const T& operator*() const;
        const T* operator-> () const;
        T& operator*();
        T* operator->();
        iteratore& operator++();
        iteratore &operator++(int);
        bool operator==(const iteratore&) const;
        bool operator!=(const iteratore&) const;
        iteratore& operator=(const iteratore&);

    };

    iteratore begin() const;
    iteratore end() const;

    void pushback(const T&);
    bool trovanodo(const T&);
    void remove(const T&);
    bool empty() const;
    void sostituisciNodo(const T& oldNodo, const T& newNodo);
    void svuotaDatabase();


};


template<class T>
database<T>::nodo::nodo(const T& t, nodo*n) : info(t), next(n) {}

template<class T>
database<T>::nodo::nodo(const nodo&n) :info(n.info), next(n.next) {}

template<class T>
void database<T>::nodo::elimina()
{
    if (next) next->elimina();
    delete this;
}

template<class T>
typename database<T>::nodo* database<T>::copia(nodo * pri, nodo *& ult)
{
    if (pri == nullptr)
    {
        ult = nullptr;
        return nullptr;
    }
    nodo* p = new nodo(pri->info, copia(pri->next, ult));
    if(pri->next == nullptr) ult = p;
    return p;
}


//=====================================

template<class T>
database<T>::database() : first(nullptr), last(nullptr), conta_nodi(0) {}

template<class T>
database<T>::database(const database & q) : first(copia(q.first, last)), conta_nodi(q.conta_nodi) {}

template<class T>
database<T>::~database (){
    this->svuotaDatabase();
}

template<class T>
database<T>& database<T>:: operator=(const database& d) {
    if(this != &d)
    {
        if(first)
            delete  first;
        first=copia(d.first, last);
    }
    return *this;
}

template<class T>
void database<T>::aumenta_conta(){
    conta_nodi++;
    return;
}

//=============================================

template<class T>
database<T>::iteratore:: iteratore() : ptr(nullptr){}

template<class T>
database<T>::iteratore:: iteratore(nodo*n) : ptr(n) {}


template<class T>
const T& database<T>::iteratore:: operator*() const {
      return ptr->info;
    }

template<class T>
const T* database<T>::iteratore:: operator->() const {
  return &(ptr->info);
}

template<class T>
T& database<T>::iteratore:: operator*(){
    return ptr->info;
}

template<class T>
T* database<T>::iteratore :: operator->(){
    return &(ptr->info);
}

template<class T>
typename database<T>::iteratore& database<T>::iteratore::operator++() {
    if(ptr) ptr=ptr->next;
          return *this;
}

template<class T>
bool database<T>::iteratore:: operator==(const iteratore& x) const {
  return ptr==x.ptr;
}

template<class T>
bool database<T>::iteratore:: operator!=(const iteratore& x) const {
  return ptr!=x.ptr;
}

template<class T>
typename database<T>::iteratore & database<T>::iteratore:: operator=(const iteratore& i){
    if(this!=&i)
        ptr=i.ptr;
    return *this;
}

template<class T>
typename database<T>::iteratore database<T>::begin() const
{
    return iteratore(first);
}

template<class T>
typename database<T>::iteratore database<T>::end() const {
    iteratore aux;
    aux.ptr=0;
    return aux;
}

//=========================================


template<class T>
void database<T>:: pushback(const T&t){
    nodo*q=new nodo(t);
    if(!first) {
        first=last=q;
        aumenta_conta();
    }
    else {
        last->next=q;
        last=last->next;
        aumenta_conta();
    }
}


template<class T>
bool database<T>::trovanodo(const T& i){
    bool trovato=false;

    if(first->info == i)
        trovato=true;
    if(last->info==i)
        trovato=true;

    nodo* scorri=first;

    while(scorri->next && !trovato){
        if(scorri->info == i)
            trovato=true;
        else
            scorri=scorri->next;
    }
    return trovato;
}

template<class T>
void database<T>::sostituisciNodo(const T& oldNodo, const T& newNodo){

    if(this->trovanodo(oldNodo)){
        if(first->info == oldNodo)
            first->info = newNodo;
        if(last->info==oldNodo)
            last->info = newNodo;

        nodo* scorri=first;

        bool done = false;
        while(scorri->next && !done){
            if(scorri->info == oldNodo){
                scorri->info = newNodo;
                done = true;
            }
            else
                scorri=scorri->next;
        }

        delete oldNodo;
    }

}


template<class T>
void database<T>::remove(const T &i)
{
    if(trovanodo(i) == true){
    //caso 1
        if(first->info == i){
            nodo*elim=first;
            first=first->next;
            elim->next=nullptr;
            delete elim;
            conta_nodi--;
        }

        else{
            nodo*scorri=first->next;
            nodo*prec=first;

            while(scorri->info != i){
                scorri=scorri->next;
                prec=prec->next;
            }
            //caso 2
            if(scorri->info==last->info){
                prec->next=nullptr;
                last=prec;
                delete scorri;
                conta_nodi--;
            }
            //caso 3
            else{
                nodo*elim=scorri;
                prec->next=scorri->next;
                elim->next=nullptr;
                delete elim;
                conta_nodi--;
            }
        }
    }
    return;
}


template<class T>
bool database<T>::empty() const
{
    if(first==nullptr)  return true;
    else
        return false;
}


template<class T>
void database<T>::svuotaDatabase()
{

    if (first!= nullptr && first){
            first->elimina();
            first = nullptr;
        }


    conta_nodi=0;
}


#endif // DATABASE_H
