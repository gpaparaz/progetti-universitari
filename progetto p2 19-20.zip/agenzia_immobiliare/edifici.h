#ifndef EDIFICI_H
#define EDIFICI_H
#include <string>
#include "immobile.h"
#include"affitto.h"
#include"vendita.h"
using std::string;

class edifici :  public vendita,  public affitto
{
private:
    int posto_auto;
    int bagni;
    int camere_letto;
    int terrazza;
    string classe_energ;
    int anno_costr;

public:
    edifici(string i="", int s_t=0, string a="", string co="",
            double p_b=0, string dest="", bool vend=false,
            double p_m=0, int d_c=0, bool disp=false,
            int p_a=0, int b=1, int c_l=1, int t=0, string c_e="", int a_c=0);

    virtual ~edifici()= default;

    int getPosto_auto() const;
    int getBagni() const;
    int getCamere() const;
    int getTerrazza() const;
    string getClasse() const;
    int getAnno() const;

    void setPostoAuto(int);
    void setBagni(int);
    void setCamereLetto(int);
    void setTerrazza(int);
    void setClasseEn(string);
    void setAnnoCostr(int);

    virtual string getTipo() const=0;
    virtual double anticipo() const=0;
    virtual double prezzoFinale() const=0;
    virtual double commissione_affitto() const=0;
    virtual double commissione_guadagno() const=0;


};

#endif // EDIFICI_H
