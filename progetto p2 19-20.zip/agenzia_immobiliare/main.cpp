#include "controller.h"
#include <QApplication>
#include <model.h>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    controller w(nullptr);

    return a.exec();
}
