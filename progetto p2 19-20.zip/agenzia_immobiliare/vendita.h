#ifndef VENDITA_H
#define VENDITA_H
#include <string>
#include<immobile.h>
using std::string;

class vendita: virtual public immobile
{
private:
    double prezzo_base;
    string proprietario;
    bool in_vendita; //se è previsto che sia venduto

public:
    vendita(string i="", int s_t=0, string a="", string co="",
            double p_b=0, string dest="", bool vend=false);

    virtual ~vendita() = default;

    void setPrezzoBase(double prezzo_b);
    void setDestVendita(string dest);
    void setInVendita(bool vend);

    double getPrezzo_base() const;
    string getproprietario() const;
    bool getVendesi() const;

    virtual double prezzoFinale() const =0;
    virtual double anticipo() const=0;
    virtual double commissione_guadagno() const=0;

};

#endif // VENDITA_H
