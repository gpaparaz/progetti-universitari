#include "edifici.h"

edifici::edifici(string i, int s_t, string a, string co,
                 double p_b, string dest, bool vend,
                 double p_m, int d_c, bool disp,
                 int p_a, int b, int c_l, int t, string c_e, int a_c) :
    vendita(i, s_t, a, co, p_b, dest, vend),
    affitto(i, s_t, a, co, p_m, d_c, disp),
    posto_auto(p_a), bagni(b), camere_letto(c_l), terrazza(t), classe_energ(c_e), anno_costr(a_c) {}

int edifici::getPosto_auto() const
{
    return posto_auto;
}

int edifici::getBagni() const
{
    return bagni;
}

int edifici::getCamere() const
{
    return camere_letto;
}

int edifici::getTerrazza() const
{
    return terrazza;
}

string edifici::getClasse() const
{
    return classe_energ;
}

int edifici::getAnno() const
{
    return anno_costr;
}

void edifici::setPostoAuto(int posto)
{
    posto_auto=posto;
}

void edifici::setBagni(int bath)
{
    bagni=bath;
}

void edifici::setCamereLetto(int room)
{
    camere_letto=room;
}

void edifici::setTerrazza(int terr)
{
    terrazza=terr;
}

void edifici::setClasseEn(string classe)
{
    classe_energ=classe;
}

void edifici::setAnnoCostr(int anno)
{
    anno_costr=anno;
}
