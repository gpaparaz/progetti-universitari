#include "vendita.h"


vendita::vendita(string i, int s_t, string a, string co,
                 double p_b, string dest, bool vend) :
    immobile(i,s_t,a,co), prezzo_base(p_b), proprietario(dest), in_vendita(vend) {}

void vendita::setPrezzoBase(double prezzo_b)
{
    prezzo_base=prezzo_b;
}

void vendita::setDestVendita(string dest)
{
    proprietario=dest;
}
void vendita::setInVendita(bool vend)
{
    in_vendita=vend;
}


double vendita::getPrezzo_base() const
{
    return prezzo_base;
}

string vendita::getproprietario() const
{
    return proprietario;
}

bool vendita::getVendesi() const
{
    return in_vendita;
}


