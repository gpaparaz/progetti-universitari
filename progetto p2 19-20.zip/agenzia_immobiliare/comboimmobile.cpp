#include "comboimmobile.h"

ComboImmobile::ComboImmobile(QWidget* parent): QComboBox (parent)
{
      addItem("Tipo di Immobile");
      addItem("Villa");
      addItem("Appartamento");
      addItem("Terreno");
}

