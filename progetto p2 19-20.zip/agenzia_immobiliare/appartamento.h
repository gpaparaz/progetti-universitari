#ifndef APPARTAMENTO_H
#define APPARTAMENTO_H
#include <edifici.h>
using std::string;

class appartamento : public edifici
{
private:
    bool ascensore;
    int piano;
    double spese_condominio;
    bool attico;

public:
    appartamento(string i="", int s_t=0, string a="", string co="",
                 double p_b=0, string dest="", bool vend=false,
                 double p_m=0, int d_c=0, bool disp=false,
                 int p_a=0, int b=1, int c_l=1, int t=0, string c_e="", int a_c=0,
                 bool lift=false, int pi=1, double s_c=0, bool att=false);

    bool getLift() const;
    int getPiano() const;
    double getSpese() const;
    bool getAttico() const;

    void setAscensore(bool);
    void setPiano(int);
    void setSpeseCond(double);
    void setAttico(bool);

    double prezzoFinale() const override;
    double anticipo() const override;
    double commissione_affitto() const override;
    double commissione_guadagno() const override;
    string getTipo() const override;
    appartamento *clone() const;
};

#endif // APPARTAMENTO_H
