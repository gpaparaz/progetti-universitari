#ifndef TERRENO_H
#define TERRENO_H
#include "immobile.h"
#include "vendita.h"
using std::string;

class terreno : public vendita
{
private:
    bool edificabile;
    bool piantamento;
    int superficie_edif;
    bool commerciale;

public:
    terreno(string i="", int s_t=0, string a="", string co="",
            double p_b=0, string dest="", bool vend=false,
            bool edif=false, bool piant=false, int sup_edif=0, bool comm=true);

    bool getEdif() const;
    bool getPiant() const;
    int getSup_edif() const;
    bool getComm() const;

    void setEdif(bool edifici);
    void setPiant(bool piante);
    void setSup_Ed(int sup_e);
    void setComm(bool commerc);

    double anticipo() const override;
    double prezzoFinale() const override;
    double commissione_guadagno() const override;
    string getTipo() const override;
    terreno *clone() const;

};

#endif // TERRENO_H
