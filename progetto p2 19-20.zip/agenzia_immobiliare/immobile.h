#ifndef IMMOBILE_H
#define IMMOBILE_H
#include <string>
using std::string;

class immobile{
private:

    string indirizzo;
    int superficie_tot;
    string altro;
    string comune;

public:
    virtual ~immobile()= default;

    immobile(string i="", int s_t=0, string a="", string co="");

    string getIndirizzo() const;
    int getSup_tot() const;
    string getAltro() const;
    string getComune() const;

    void setIndirizzo(string);
    void setSupTot(int);
    void setNote(string);
    void setComune(string);

    string getInfo() const;

    virtual string getTipo() const=0;
    virtual double prezzoFinale() const=0;
};

#endif // IMMOBILE_H
