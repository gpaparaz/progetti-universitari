#ifndef VILLA_H
#define VILLA_H
#include "edifici.h"
using std::string;

class villa : public edifici
{
private:
    int piani;
    bool mansarda;
    bool piscina;
    bool giardino;
    int schiera;
    string posizione;
public:
    villa(string i="", int s_t=0, string a="", string co="",
          double p_b=0, string dest="", bool vend=false,
          double p_m=0, int d_c=0, bool disp=false,
          int p_a=0, int b=1, int c_l=1, int t=0, string c_e="", int a_c=0,
          int pian=1, bool m=false, bool sw=false, bool garden=true, int sch=0, string pos="");

    int getPiani() const;
    bool getMansarda() const;
    bool getPiscina() const;
    bool getGiardino() const;
    int getSchiera() const;
    string getPosizione() const;


    void setPiani(int);
    void setMansarda(bool);
    void setPiscina(bool);
    void setGiardino(bool);
    void setSchiera(int);
    void setPosizione(string);

    double anticipo() const override;
    double prezzoFinale() const override;
    double commissione_affitto() const  override;
    double commissione_guadagno() const override;
    string getTipo() const override;
    villa *clone() const;


};

#endif // VILLA_H
