#include "mainwindow.h"

mainwindow::mainwindow( QWidget *parent)
    : QWidget(parent), elencoImmobili(new listaimmobili(this))
{
   setWindowTitle("Agenzia Immobiliare PaGi");
   finestra_base= new QVBoxLayout(this);
   setWindowIcon(QIcon(":pagi_ico.jpg"));
   setMinimumSize(800,800);

   //IMMAGINE
   QHBoxLayout*riquadro_immagine=new QHBoxLayout();
   QPixmap*  pix = new QPixmap(":pagi_home.jpg");
   QLabel* immagine = new QLabel(this);
   immagine->setPixmap(*pix);
   immagine->setAlignment(Qt::AlignHCenter);
   riquadro_immagine->addWidget(immagine);
   finestra_base->addLayout(riquadro_immagine);

//box filtri layout orizzontale

   QGroupBox* filtri= new QGroupBox("Ricerca per");
   QGridLayout*sotto_tipi=new QGridLayout();

   filtroVille= new QPushButton("Ville", this);
   filtroVilleSingole= new QPushButton("Ville Singole", this);
   filtroAppartamenti= new QPushButton("Appartamenti", this);
   filtroTerreni= new QPushButton("Terreni", this);
   filtroTerreniEdif= new QPushButton("Terreni Edificabili", this);
   filtroTerreniAgric= new QPushButton("Terreni Agricoli", this);
   filtroVilleSchiera=new QPushButton("Ville a schiera", this);
   filtroAppartSpese=new QPushButton("Spese annue < 3000 €", this);
   filtroAppAttico=new QPushButton("Appartamenti con Attico", this);

   sotto_tipi->addWidget(filtroVille, 0, 0);
   sotto_tipi->addWidget(filtroVilleSchiera, 0, 1);
   sotto_tipi->addWidget(filtroVilleSingole, 0,2);
   sotto_tipi->addWidget(filtroAppartamenti, 1, 0);
   sotto_tipi->addWidget(filtroAppartSpese, 1, 1);
   sotto_tipi->addWidget(filtroAppAttico,1,2);
   sotto_tipi->addWidget(filtroTerreni, 2, 0);
   sotto_tipi->addWidget(filtroTerreniAgric, 2, 1);
   sotto_tipi->addWidget(filtroTerreniEdif, 2, 2);

   filtroImmobiliProp=new QPushButton("Immobili PaGi", this);

   sotto_tipi->addWidget(filtroImmobiliProp, 3, 0, 1, 3);
   filtri->setLayout(sotto_tipi);
   finestra_base->addWidget(filtri);


//box filtri layout filtri vendita e affitto

    QGroupBox* ven_aff_filtri= new QGroupBox("Condizioni:");
    QHBoxLayout* flayout_ven_aff= new QHBoxLayout();
    filtroAffittabili= new QPushButton("Affitti", this);
    filtroInVendita= new QPushButton("In Vendita", this);

    rimuoviFiltri= new QPushButton("Rimuovi Filtro", this);

    flayout_ven_aff->addWidget(filtroAffittabili);
    flayout_ven_aff->addWidget(filtroInVendita);
    ven_aff_filtri->setLayout(flayout_ven_aff);
    finestra_base->addWidget(ven_aff_filtri);

    finestra_base->addWidget(rimuoviFiltri);

    //BARRA DI RICERCA
    ricerca=new QLineEdit(this);
    ricerca->setPlaceholderText("Cerca Comune");
    finestra_base->addWidget(ricerca);


//Qlistwidget: come mostrare la lista clienti
    elencoImmobili->setSelectionMode(QAbstractItemView::SingleSelection);
    finestra_base->addWidget(elencoImmobili);


   //parte bottoni modifica elimina etc layout orizzontale
   QGroupBox* bottoni_modifica= new QGroupBox("Azioni");
   QHBoxLayout* layout_bottoni_modifica= new QHBoxLayout();
   visualizza_immobile= new QPushButton("Visualizza", this);
   inserisci_immobile= new QPushButton("Inserisci Immobile", this);
   modifica_immobile= new QPushButton("Modifica", this);
   rimuovi_immobile= new QPushButton("Elimina", this);
   layout_bottoni_modifica->addWidget(visualizza_immobile);
   layout_bottoni_modifica->addWidget(inserisci_immobile);
   layout_bottoni_modifica->addWidget(modifica_immobile);
   layout_bottoni_modifica->addWidget(rimuovi_immobile);
   bottoni_modifica->setLayout(layout_bottoni_modifica);

   finestra_base->addWidget(bottoni_modifica);


   rimuoviFiltri->setStyleSheet("background-color:#70dbdb; ");
   rimuovi_immobile->setStyleSheet("background-color:#70dbdb;");

   filtroAffittabili->setStyleSheet("background-color:#adebeb; ");
   filtroInVendita->setStyleSheet("background-color:#adebeb; ");
   visualizza_immobile->setStyleSheet("background-color:#adebeb; ");
   inserisci_immobile->setStyleSheet("background-color:#adebeb");
   modifica_immobile->setStyleSheet("background-color:#adebeb;");

   filtroTerreni->setStyleSheet("background-color:#adebeb;");
   filtroTerreniAgric->setStyleSheet("background-color:#adebeb;");
   filtroTerreniEdif->setStyleSheet("background-color:#adebeb;");
   filtroVille->setStyleSheet("background-color:#adebeb;");
   filtroVilleSingole->setStyleSheet("background-color:#adebeb;");
   filtroAppartamenti->setStyleSheet("background-color:#adebeb;");
   filtroImmobiliProp->setStyleSheet("background-color:#adebeb;");
   filtroAppartSpese->setStyleSheet("background-color:#adebeb;");
   filtroAppAttico->setStyleSheet("background-color:#adebeb;");
   filtroVilleSchiera->setStyleSheet("background-color:#adebeb;");


   connect(inserisci_immobile, SIGNAL(clicked()), this, SIGNAL(signalApriInserisci()));
   connect(visualizza_immobile,SIGNAL(clicked()),this,SIGNAL(signalVisualizzaImmob()));
   connect(modifica_immobile,SIGNAL(clicked()),this,SIGNAL(signalModificaImmob()));
   connect(rimuovi_immobile, SIGNAL(clicked()),this, SIGNAL(signalRimuoviImmobile()));

   connect(filtroVille, SIGNAL(clicked()),this, SIGNAL(signalFiltroVilla()));
   connect(filtroAppartamenti, SIGNAL(clicked()),this, SIGNAL(signalFiltroAppartamento()));
   connect(filtroTerreni, SIGNAL(clicked()),this, SIGNAL(signalFiltroTerreno()));
   connect(filtroAffittabili, SIGNAL(clicked()),this, SIGNAL(signalFiltroAffittabile()));
   connect(filtroInVendita, SIGNAL(clicked()),this, SIGNAL(signalFiltroInVendita()));
   connect(filtroTerreniAgric, SIGNAL(clicked()),this, SIGNAL(signalFiltroTerrenoAgricolo()));
   connect(filtroTerreniEdif, SIGNAL(clicked()),this, SIGNAL(signalFiltroTerrenoEdificabile()));
   connect(filtroVilleSingole, SIGNAL(clicked()),this, SIGNAL(signalFiltroVillaSingola()));
   connect(rimuoviFiltri, SIGNAL(clicked()),this, SIGNAL(signalRimuoviFiltro()));
   connect(filtroAppartSpese, SIGNAL(clicked(bool)),this, SIGNAL(signalFiltroAppSpese()));
   connect(filtroAppAttico,SIGNAL(clicked(bool)),this, SIGNAL(signalFiltroAppAttico()));
   connect(filtroVilleSchiera,SIGNAL(clicked(bool)),this, SIGNAL(signalFiltroVillaSchiera()));
   connect(filtroImmobiliProp, SIGNAL(clicked(bool)),this, SIGNAL(signalFiltroImmobPropri()));

   connect(ricerca, SIGNAL(textChanged(const QString &)), this, SIGNAL(signalCercaCampo()));
}


listaimmobili* mainwindow::getIommobileListWidget(){
    return this->elencoImmobili;
}

const QString mainwindow::getCampoCerca() const
{
    return ricerca->text();
}

void mainwindow::closeEvent(QCloseEvent *)
{
    emit esci();
}


