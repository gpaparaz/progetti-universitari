#include "modimmobilewindow.h"

modimmobilewindow::modimmobilewindow(QWidget *parent) : addimmobilewindow(parent)
{
    setWindowTitle("Modifica Immobile");
    setWindowIcon(QIcon(":pagi_ico.jpg"));
    setMinimumSize(700, 700);

}


modimmobilewindow::~modimmobilewindow(){
    if(this->imm){
        delete this->imm;
    }
}

void modimmobilewindow::clear(){
    this->imm = nullptr;
    this->azzeraCampi();
}


void modimmobilewindow::setImmobileDaModificare(immobile *imm){
        this->imm = imm;
}


immobile* modimmobilewindow::getImmobileDaModificare(){
    return this->imm;
}

void modimmobilewindow::inserisci(){
    emit signalModificaI();
}

void modimmobilewindow::caricaCampiModifica(listaImmobiliOggetto* imm){

    immobile*i= imm->getItem();

    terreno*t=dynamic_cast<terreno*>(i);
    appartamento*a=dynamic_cast<appartamento*>(i);
    villa*v=dynamic_cast<villa*>(i);

    comune->clear();
    comune->setText(QString::fromStdString(i->getComune()));

    indirizzo->clear();
    indirizzo->setText(QString::fromStdString(i->getIndirizzo()));

    sup_totale->clear();
    sup_totale->setText(QString::fromStdString( std::to_string(i->getSup_tot())));

    altro->clear();
    altro->setText(QString::fromStdString(i->getAltro()));

    if(a){

        tipo_immobile->setCurrentIndex(2);
        sDisabilitaCQ(2);

        comune->clear();
        comune->setText(QString::fromStdString(a->getComune()));

        indirizzo->clear();
        indirizzo->setText(QString::fromStdString(a->getIndirizzo()));

        sup_totale->clear();
        sup_totale->setText(QString::fromStdString( std::to_string(a->getSup_tot())));

        altro->clear();
        altro->setText(QString::fromStdString(a->getAltro()));


        if(dynamic_cast<edifici*>(a)){
            posto_auto->clear();
            posto_auto->setText(QString::fromStdString( std::to_string(a->getPosto_auto())));

            bagni->clear();
            bagni->setText(QString::fromStdString(std::to_string(a->getBagni())));

            camere->clear();
            camere->setText(QString::fromStdString(std::to_string(a->getCamere())));

            terrazza->clear();
            terrazza->setText(QString::fromStdString(std::to_string(a->getTerrazza())));

            classe_en->clear();
            classe_en->setText(QString::fromStdString(a->getClasse()));

            anno_costr->clear();
            anno_costr->setText(QString::fromStdString(std::to_string(a->getAnno())));
        }

        //campi specifici a
        ascensore->setChecked(a->getLift());

        piano->clear();
        piano->setText(QString::fromStdString(std::to_string(a->getPiano())));

        spese_cond->clear();
        spese_cond->setValue(a->getSpese());

        attico->setChecked(a->getAttico());

        if(dynamic_cast<affitto*>(a)){
            //affittabile->setChecked(a->getAffitt());
            prezzo_mensile->clear();
            prezzo_mensile->setValue(a->getPrezzoMens());
            contratto->clear();
            contratto->setText(QString::fromStdString( std::to_string(a->getContratto())));
            disponibile_affitto->setChecked(a->getDisponib());

        }
        if(dynamic_cast<vendita*>(a)){
            in_vendita->setChecked(a->getVendesi());
            proprietario_vendita->clear();
            proprietario_vendita->setText(QString::fromStdString(a->getproprietario()));
            prezzo_base->clear();
            prezzo_base->setValue(a->getPrezzo_base());

        }
    }
    else if(v){

        tipo_immobile->setCurrentIndex(1);
        sDisabilitaCQ(1);

        comune->clear();
        comune->setText(QString::fromStdString(v->getComune()));

        indirizzo->clear();
        indirizzo->setText(QString::fromStdString(v->getIndirizzo()));

        sup_totale->clear();
        sup_totale->setText(QString::fromStdString( std::to_string(v->getSup_tot())));

        altro->clear();
        altro->setText(QString::fromStdString(v->getAltro()));

        if(dynamic_cast<edifici*>(v)){
            posto_auto->clear();
            posto_auto->setText(QString::fromStdString( std::to_string(v->getPosto_auto())));

            bagni->clear();
            bagni->setText(QString::fromStdString(std::to_string(v->getBagni())));

            camere->clear();
            camere->setText(QString::fromStdString(std::to_string(v->getCamere())));

            terrazza->clear();
            terrazza->setText(QString::fromStdString(std::to_string(v->getTerrazza())));

            classe_en->clear();
            classe_en->setText(QString::fromStdString(v->getClasse()));

            anno_costr->clear();
            anno_costr->setText(QString::fromStdString(std::to_string(v->getAnno())));
        }

        //campi specifici di v
        piani->clear();
        piani->setText(QString::fromStdString(std::to_string(v->getPiani())));

        mansardata->setChecked(v->getMansarda());

        piscina->setChecked(v->getPiscina());

        giardino->setChecked(v->getGiardino());

        schiera->clear();
        schiera->setText(QString::fromStdString(std::to_string(v->getSchiera())));

        posizione->clear();
        posizione->setText(QString::fromStdString(v->getPosizione()));

        if(dynamic_cast<affitto*>(v)){
            //affittabile->setChecked(v->getAffitt());
            prezzo_mensile->clear();
            prezzo_mensile->setValue(v->getPrezzoMens());
            contratto->clear();
            contratto->setText(QString::fromStdString( std::to_string(v->getContratto())));
            disponibile_affitto->setChecked(v->getDisponib());
         }

        if(dynamic_cast<vendita*>(v)){
            in_vendita->setChecked(v->getVendesi());
            proprietario_vendita->clear();
            proprietario_vendita->setText(QString::fromStdString(v->getproprietario()));
            prezzo_base->clear();
            prezzo_base->setValue(v->getPrezzo_base());
        }
    }
    else if(t){

        tipo_immobile->setCurrentIndex(3);
        sDisabilitaCQ(3);

        comune->clear();
        comune->setText(QString::fromStdString(t->getComune()));

        indirizzo->clear();
        indirizzo->setText(QString::fromStdString(t->getIndirizzo()));

        sup_totale->clear();
        sup_totale->setText(QString::fromStdString( std::to_string(t->getSup_tot())));

        altro->clear();
        altro->setText(QString::fromStdString(t->getAltro()));

        //campi specifici di t
        edificabile->setChecked(t->getEdif());

        piantamento->setChecked(t->getPiant());

        sup_edificab->clear();
        sup_edificab->setText(QString::fromStdString(std::to_string(t->getSup_edif())));

        commerciale->setChecked(t->getComm());

        if(dynamic_cast<vendita*>(t)){
            in_vendita->setChecked(t->getVendesi());
            proprietario_vendita->clear();
            proprietario_vendita->setText(QString::fromStdString(t->getproprietario()));
            prezzo_base->clear();
            prezzo_base->setValue(t->getPrezzo_base());
            }

    }

}
