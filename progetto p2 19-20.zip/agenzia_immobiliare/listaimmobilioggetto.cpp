#include "listaimmobilioggetto.h"

listaImmobiliOggetto::listaImmobiliOggetto(immobile* i, QWidget* p): item(i), parent(p)
{
    update();
}
void listaImmobiliOggetto::update(){
    setText(QString::fromStdString(item->getInfo()));

}

immobile* listaImmobiliOggetto::getItem(){
    return this->item;
}

