#ifndef LISTAIMMOBILIOGGETTO_H
#define LISTAIMMOBILIOGGETTO_H

#include <QListWidgetItem>
#include <QWidget>
#include <immobile.h>

class listaImmobiliOggetto: public QListWidgetItem{

private:
    immobile *item;
    QWidget* parent;

public:

    listaImmobiliOggetto(immobile*, QWidget* =nullptr);
    void update();
    immobile* getItem();
};

#endif // LISTAIMMOBILIOGGETTO_H
