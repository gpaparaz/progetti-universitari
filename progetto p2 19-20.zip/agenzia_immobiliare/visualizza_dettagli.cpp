#include "visualizza_dettagli.h"
using namespace std;

VisualizzaDettagli::VisualizzaDettagli(QWidget *parent) : QWidget(parent),
    immobile_tipo(new QLabel(this)), prezzo_mensile(new QLabel(this)),contratto(new QLabel(this)), disponibilita(new QLabel(this)),
    proprietario_vendita(new QLabel(this)), inVendita(new QLabel(this)),
    indirizzo(new QLabel(this)), sup_totale(new QLabel(this)), altro(new QLabel(this)), affittabile(new QLabel(this)), comune(new QLabel(this)),
    posto_auto(new QLabel(this)), bagni(new QLabel(this)), camere(new QLabel(this)), terrazza(new QLabel(this)), classe_en(new QLabel(this)), anno_costr(new QLabel(this)),
    piani(new QLabel(this)), mansardata(new QLabel(this)), piscina(new QLabel(this)), giardino(new QLabel(this)), schiera(new QLabel(this)),posizione(new QLabel(this)),
    ascensore(new QLabel(this)), piano(new QLabel(this)), spese_cond(new QLabel(this)), attico(new QLabel(this)),
    edificabile(new QLabel(this)), piantamento(new QLabel(this)), sup_edificab(new QLabel(this)), commerciale(new QLabel(this)),
    prezzoFinale(new QLabel(this)), commissioni_affit(new QLabel(this)), anticipo(new QLabel(this)), guadagno(new QLabel(this))
{
    setWindowTitle("Dettagli Immobile");
    setWindowIcon(QIcon(":pagi_ico.jpg"));
    finestra_vis_base= new QHBoxLayout(this);
    setMinimumSize(500,400);
    setLayout(finestra_vis_base);
    layout_vis_sx=new QVBoxLayout();
    layout_vendita_vis_dx=new QVBoxLayout();

    layout_vis_sx->addWidget(immobile_tipo);
    immobile_tipo->setMaximumHeight(50);
    finestra_vis_base->addLayout(layout_vis_sx);


//pezzo generali
    QFormLayout *gen_vis_flayout = new QFormLayout();

    QLabel *comune_label=new QLabel("Comune: ");
    gen_vis_flayout->addRow(comune_label, comune);

    QLabel *indirizzo_label=new QLabel("Indirizzo: ");
    gen_vis_flayout->addRow(indirizzo_label, indirizzo);

    QLabel *sup_totale_label=new QLabel("Superficie Totale: ");
    gen_vis_flayout->addRow(sup_totale_label, sup_totale);

    QLabel *altro_label=new QLabel("Altri dettagli: ");
    gen_vis_flayout->addRow(altro_label, altro);

    info_generali= new QGroupBox(this);
    info_generali->setLayout(gen_vis_flayout);
    layout_vis_sx->addWidget(info_generali);


//pezzo edifici
    QFormLayout *edif_vis_flayout = new QFormLayout();

    QLabel *posto_auto_label=new QLabel("Numero posti auto: ");
    edif_vis_flayout->addRow(posto_auto_label, posto_auto);

    QLabel *bagni_label=new QLabel("Numero Bagni: ");
    edif_vis_flayout->addRow(bagni_label, bagni);

    QLabel *camere_label=new QLabel("Numero Camere da letto: ");
    edif_vis_flayout->addRow(camere_label, camere);

    QLabel *terrazza_label=new QLabel("Numero terrazze: ");
    edif_vis_flayout->addRow(terrazza_label, terrazza);

    QLabel *classe_en_label=new QLabel("Classe energetica: ");
    edif_vis_flayout->addRow(classe_en_label, classe_en);

    QLabel *anno_costr_label=new QLabel("Anno di costruzione: ");
    edif_vis_flayout->addRow(anno_costr_label, anno_costr);

    info_edificio= new QGroupBox(this);
    info_edificio->setLayout(edif_vis_flayout);
    layout_vis_sx->addWidget(info_edificio);


//pezzo affitto
    QFormLayout *affit_vis_flayout = new QFormLayout();

    QLabel *prezzo_mensile_label=new QLabel("Prezzo mensile: ");
    affit_vis_flayout->addRow(prezzo_mensile_label, prezzo_mensile);

    QLabel *contratto_label=new QLabel("Contratto: ");
    affit_vis_flayout->addRow(contratto_label, contratto);

    QLabel *disponibilita_label=new QLabel("Attualmente libera: ");
    affit_vis_flayout->addRow(disponibilita_label, disponibilita);

    QLabel *commissioni_affit_label=new QLabel("Commissioni d'Affitto: ");
    affit_vis_flayout->addRow(commissioni_affit_label, commissioni_affit);

    info_affitto= new QGroupBox(this);
    info_affitto->setLayout(affit_vis_flayout);

    layout_vendita_vis_dx->addWidget(info_affitto);
    finestra_vis_base->addLayout(layout_vendita_vis_dx);


//pezzo vendita
    QFormLayout *vend_vis_flayout = new QFormLayout();

    QLabel *inVendita_label=new QLabel("In vendita: ");
    vend_vis_flayout->addRow(inVendita_label, inVendita);

    QLabel *proprietario_vendita_label=new QLabel("Proprietario dell'immobile: ");
    vend_vis_flayout->addRow(proprietario_vendita_label, proprietario_vendita);

    QLabel *prezzoFinale_label=new QLabel("Prezzo: ");
    vend_vis_flayout->addRow(prezzoFinale_label, prezzoFinale);

    QLabel *anticipo_label=new QLabel("Di cui da Anticipare: ");
    vend_vis_flayout->addRow(anticipo_label, anticipo);

    QLabel *guadagno_label=new QLabel("Guadagno sulla vendita: ");
    vend_vis_flayout->addRow(guadagno_label, guadagno);

    info_vendita= new QGroupBox(this);
    info_vendita->setLayout(vend_vis_flayout);
    layout_vendita_vis_dx->addWidget(info_vendita);



//pezzo villa
    QFormLayout *villa_vis_flayout = new QFormLayout();

    QLabel *piani_label=new QLabel("Numero piani: ");
    villa_vis_flayout->addRow(piani_label, piani);

    QLabel *mansardata_label=new QLabel("Mansardata: ");
    villa_vis_flayout->addRow(mansardata_label, mansardata);

    QLabel *piscina_label=new QLabel("Piscina: ");
    villa_vis_flayout->addRow(piscina_label, piscina);

    QLabel *giardino_label=new QLabel("Giardino: ");
    villa_vis_flayout->addRow(giardino_label, giardino);

    QLabel *schiera_label=new QLabel("Quante schiera: ");
    villa_vis_flayout->addRow(schiera_label, schiera);

    QLabel*posizione_label=new QLabel("In posizione: ");
    villa_vis_flayout->addRow(posizione_label, posizione);

    info_villa= new QGroupBox(this);
    info_villa->setLayout(villa_vis_flayout);
    layout_vis_sx->addWidget(info_villa);


//pezzo appart
    QFormLayout *appart_vis_flayout = new QFormLayout();

    QLabel *ascensore_label=new QLabel("Ascensore: ");
    appart_vis_flayout->addRow(ascensore_label, ascensore);

    QLabel *piano_label=new QLabel("Al piano: ");
    appart_vis_flayout->addRow(piano_label, piano);

    QLabel *spese_cond_label=new QLabel("Spese condominiali annue: ");
    appart_vis_flayout->addRow(spese_cond_label, spese_cond);

    QLabel *attico_label=new QLabel("Con Attico: ");
    appart_vis_flayout->addRow(attico_label, attico);

    info_appart= new QGroupBox(this);
    info_appart->setLayout(appart_vis_flayout);
    layout_vis_sx->addWidget(info_appart);


//pezzo terreno
    QFormLayout *ter_vis_flayout = new QFormLayout();

    QLabel *edificabile_label=new QLabel("Edificabile: ");
    ter_vis_flayout->addRow(edificabile_label, edificabile);

    QLabel *piantamento_label=new QLabel("Piantamento: ");
    ter_vis_flayout->addRow(piantamento_label, piantamento);

    QLabel *sup_edificab_label=new QLabel("Superficie Edificabile: ");
    ter_vis_flayout->addRow(sup_edificab_label, sup_edificab);

    QLabel *commerciale_label=new QLabel("Commerciale: ");
    ter_vis_flayout->addRow(commerciale_label, commerciale);

    info_terreno= new QGroupBox(this);
    info_terreno->setLayout(ter_vis_flayout);
    layout_vis_sx->addWidget(info_terreno);

//bottone elimina
    chiudi=new QPushButton("Esci",this);
    layout_vendita_vis_dx->addWidget(chiudi);
    connect(chiudi,SIGNAL(clicked()),this,SLOT(close()));

}

void VisualizzaDettagli::riempiCampi(listaImmobiliOggetto* imm){

    immobile*i= imm->getItem();

    terreno*t=dynamic_cast<terreno*>(i);
    villa*v=dynamic_cast<villa*>(i);
    appartamento*a=dynamic_cast<appartamento*>(i);

    comune->clear();
    comune->setText(QString::fromStdString(i->getComune()));

    indirizzo->clear();
    indirizzo->setText(QString::fromStdString(i->getIndirizzo()));

    sup_totale->clear();
    sup_totale->setText(QString::fromStdString( std::to_string(i->getSup_tot())));

    altro->clear();
    altro->setText(QString::fromStdString(i->getAltro()));

    if(a){
        immobile_tipo->clear();
        immobile_tipo->setText(QString::fromStdString("Appartamento:" ));
        info_edificio->setVisible(true);
        info_appart->setVisible(true);
        info_terreno->setVisible(false);
        info_villa->setVisible(false);

        if(dynamic_cast<edifici*>(a)){
            posto_auto->clear();
            posto_auto->setText(QString::fromStdString( std::to_string(a->getPosto_auto())));

            bagni->clear();
            bagni->setText(QString::fromStdString(std::to_string(a->getBagni())));

            camere->clear();
            camere->setText(QString::fromStdString(std::to_string(a->getCamere())));

            terrazza->clear();
            terrazza->setText(QString::fromStdString(std::to_string(a->getTerrazza())));

            classe_en->clear();
            classe_en->setText(QString::fromStdString(a->getClasse()));

            anno_costr->clear();
            anno_costr->setText(QString::fromStdString(std::to_string(a->getAnno())));
        }

        //campi specifici a
        ascensore->clear();
        ascensore->setText(QString::fromStdString(a->getLift()? "SÌ": "NO"));

        piano->clear();
        piano->setText(QString::fromStdString(std::to_string(a->getPiano())));

        spese_cond->clear();
        spese_cond->setText(QString::fromStdString(std::to_string(a->getSpese())).append(" €"));

        attico->clear();
        attico->setText(QString::fromStdString(a->getAttico()?"SÌ": "NO"));

        if(dynamic_cast<affitto*>(a)){
            //affittabile->clear();
            //affittabile->setText(QString::fromStdString(a->getAffitt()? "SÌ": "NO"));

            prezzo_mensile->clear();
            prezzo_mensile->setText(QString::fromStdString( std::to_string(a->getPrezzoMens())).append(" €"));

            contratto->clear();
            contratto->setText(QString::fromStdString( std::to_string(a->getContratto()).append(" mesi")));

            disponibilita->clear();
            disponibilita->setText(QString::fromStdString( a->getDisponib()? "SÌ": "NO" ));

            commissioni_affit->clear();
            commissioni_affit->setText(QString::fromStdString( std::to_string(a->commissione_affitto())).append(" €"));

        }
        if(dynamic_cast<vendita*>(a)){
            inVendita->clear();
            inVendita->setText(QString::fromStdString(a->getVendesi()? "SÌ": "NO"));

            proprietario_vendita->clear();
            proprietario_vendita->setText(QString::fromStdString(a->getproprietario()));

            anticipo->clear();
            anticipo->setText(QString::fromStdString(std::to_string(a->anticipo())).append(" €"));

            prezzoFinale->clear();
            prezzoFinale->setText(QString::fromStdString(std::to_string(a->prezzoFinale())).append(" €"));

            guadagno->clear();
            guadagno->setText(QString::fromStdString(std::to_string(a->commissione_guadagno()).append(" €")));

        }
    }
    else if(v){
        immobile_tipo->clear();
        immobile_tipo->setText(QString::fromStdString("Villa:" ));
        info_edificio->setVisible(true);
        info_appart->setVisible(false);
        info_terreno->setVisible(false);
        info_villa->setVisible(true);

        if(dynamic_cast<edifici*>(v)){
            posto_auto->clear();
            posto_auto->setText(QString::fromStdString( std::to_string(v->getPosto_auto())));

            bagni->clear();
            bagni->setText(QString::fromStdString(std::to_string(v->getBagni())));

            camere->clear();
            camere->setText(QString::fromStdString(std::to_string(v->getCamere())));

            terrazza->clear();
            terrazza->setText(QString::fromStdString(std::to_string(v->getTerrazza())));

            classe_en->clear();
            classe_en->setText(QString::fromStdString(v->getClasse()));

            anno_costr->clear();
            anno_costr->setText(QString::fromStdString(std::to_string(v->getAnno())));
        }

        //campi specifici di v
        piani->clear();
        piani->setText(QString::fromStdString(std::to_string(v->getPiani())));

        mansardata->clear();
        mansardata->setText(QString::fromStdString(v->getMansarda()?"SÌ": "NO"));

        piscina->clear();
        piscina->setText(QString::fromStdString(v->getPiscina()?"SÌ": "NO"));

        giardino->clear();
        giardino->setText(QString::fromStdString(v->getGiardino()?"SÌ": "NO"));

        schiera->clear();
        schiera->setText(QString::fromStdString(std::to_string(v->getSchiera())));

        posizione->clear();
        posizione->setText(QString::fromStdString(v->getPosizione()));

        if(dynamic_cast<affitto*>(v)){
            //affittabile->clear(); //se è previsto che sia messo in affitto
            //affittabile->setText(QString::fromStdString(v->getAffitt()? "SÌ": "NO"));

            prezzo_mensile->clear();
            prezzo_mensile->setText(QString::fromStdString( std::to_string(v->getPrezzoMens())).append(" €"));

            contratto->clear();
            contratto->setText(QString::fromStdString( std::to_string(v->getContratto()).append(" mesi")));

            disponibilita->clear();
            disponibilita->setText(QString::fromStdString( v->getDisponib()? "SÌ": "NO" )); //se attualmente è libero

            commissioni_affit->clear();
            commissioni_affit->setText(QString::fromStdString( std::to_string(v->commissione_affitto())).append(" €"));

        }
        if(dynamic_cast<vendita*>(v)){
            inVendita->clear();
            inVendita->setText(QString::fromStdString(v->getVendesi()? "SÌ": "NO"));

            proprietario_vendita->clear();
            proprietario_vendita->setText(QString::fromStdString(v->getproprietario()));

            anticipo->clear();
            anticipo->setText(QString::fromStdString(std::to_string(v->anticipo())).append(" €"));

            prezzoFinale->clear();
            prezzoFinale->setText(QString::fromStdString(std::to_string(v->prezzoFinale())).append(" €"));

            guadagno->clear();
            guadagno->setText(QString::fromStdString(std::to_string(v->commissione_guadagno()).append(" €")));

        }

    }
    else if(t){
        immobile_tipo->clear();
        immobile_tipo->setText(QString::fromStdString("Terreno:" ));
        info_edificio->setVisible(false);
        info_appart->setVisible(false);
        info_terreno->setVisible(true);
        info_villa->setVisible(false);
        info_affitto->setVisible(false);
        //campi specifici di t
        edificabile->clear();
        edificabile->setText(QString::fromStdString(t->getEdif()?"SÌ": "NO"));

        piantamento->clear();
        piantamento->setText(QString::fromStdString(t->getPiant()? "SÌ": "NO"));

        sup_edificab->clear();
        sup_edificab->setText(QString::fromStdString(std::to_string(t->getSup_edif())));

        commerciale->clear();
        commerciale->setText(QString::fromStdString(t->getComm()?"SÌ": "NO"));

        if(dynamic_cast<vendita*>(t)){
            inVendita->clear();
            inVendita->setText(QString::fromStdString(t->getVendesi()? "SÌ": "NO"));

            proprietario_vendita->clear();
            proprietario_vendita->setText(QString::fromStdString(t->getproprietario()));

            anticipo->clear();
            anticipo->setText(QString::fromStdString(std::to_string(t->anticipo())).append(" €"));

            prezzoFinale->clear();
            prezzoFinale->setText(QString::fromStdString(std::to_string(t->prezzoFinale())).append(" €"));

            guadagno->clear();
            guadagno->setText(QString::fromStdString(std::to_string(t->commissione_guadagno()).append(" €")));

        }
    }
}


