#include "listaimmobili.h"
#include <QScrollBar>
#include <mainwindow.h>
listaimmobili::listaimmobili(QWidget* p):parent(p)
{
    addScrollBarWidget(new QScrollBar(Qt::Orientation::Vertical,parent), Qt::AlignRight);

}

void listaimmobili::addImmobile(immobile *imm)
{
    listaImmobiliOggetto* item= new listaImmobiliOggetto(imm, parent);

    addItem(item);
}


listaImmobiliOggetto* listaimmobili::currentItem() const{
    return static_cast<listaImmobiliOggetto*>(QListWidget::currentItem());

}


void listaimmobili::removeImmobile(listaImmobiliOggetto*l)
{
    removeItemWidget(l);
    delete l;
}


