#ifndef ADDIMMOBILEWINDOW_H
#define ADDIMMOBILEWINDOW_H

#include<QVBoxLayout>
#include<QCheckBox>
#include<QGroupBox>
#include<QComboBox>
#include<QHBoxLayout>
#include<QLabel>
#include<QFormLayout>
#include<QLineEdit>
#include <QDoubleSpinBox>
#include<QPushButton>
#include<comboimmobile.h>
#include<immobile.h>
#include<database.h>


class addimmobilewindow: public QWidget
{
    Q_OBJECT
protected:
    QHBoxLayout *finestra_add_base;
    QVBoxLayout *layout_sx, *layout_vendita_dx;
    ComboImmobile *tipo_immobile;
    QGroupBox *info_vendita, *info_affitto, *info_generali, *info_edificio, *info_villa, *info_appart, *info_terreno, *gruppo_bottoni;
    QLineEdit  *contratto,
          *proprietario_vendita, *indirizzo, *comune, *sup_totale, *altro,
         *posto_auto, *bagni, *camere, *terrazza, *classe_en, *anno_costr,
         *piani, *schiera, *posizione,
         *piano,
         *sup_edificab;
    QDoubleSpinBox *spese_cond, *prezzo_mensile, *prezzo_base;
    QCheckBox *in_vendita, *disponibile_affitto, *affittabile, *mansardata, *piscina, *giardino,
         *ascensore, *attico,
         *edificabile, *piantamento, *commerciale;
    QPushButton *aggiungi, *annulla;

public:
    explicit addimmobilewindow(QWidget *parent = nullptr);

    QDoubleSpinBox *getAddPrezzo_mensile()const;
    QLineEdit *getAddContratto()const;

    QDoubleSpinBox *getAddPrezzo_base()const;
    QLineEdit *getAddproprietario_vendita()const;
    QLineEdit *getAddIndirizzo()const;
    QLineEdit *getAddComune()const;
    QLineEdit *getAddSup_totale()const;
    QLineEdit *getAddAltro()const;
    QLineEdit *getAddPosto_auto()const;
    QLineEdit *getAddBagni()const;
    QLineEdit *getAddCamere()const;
    QLineEdit *getAddTerrazza()const;
    QLineEdit *getAddClasse_en()const;
    QLineEdit *getAddAnno_costr()const;
    QLineEdit *getAddPiani()const;
    QLineEdit *getAddSchiera()const;
    QLineEdit *getAddPosizione()const;
    QLineEdit *getAddPiano()const;
    QDoubleSpinBox *getAddSpese_cond()const;
    QLineEdit *getAddSup_edificab()const;

    QCheckBox *getAddDisponibilita()const;
    QCheckBox *getAddInVendita()const;
    QCheckBox *getAddMansardata()const;
    QCheckBox *getAddPiscina()const;
    QCheckBox *getAddGiardino()const;
    QCheckBox *getAddAscensore()const;
    QCheckBox *getAddAttico()const;
    QCheckBox *getAddEdificabile()const;
    QCheckBox *getAddPiantamento()const;
    QCheckBox *getAddCommerciale()const;

    QPushButton *getAggiungiImm() const;
    QPushButton *getAnnulla() const;

    ComboImmobile *getTipoImmobile() const;

signals:
    void signalDisabilitaCQ(int);
    void signalInserisciI();

public slots:

    void sDisabilitaCQ(int) const;
    void azzeraCampi() const;
    void slotSeEdif();
    void slotSePiant();
    void slotSeComm();

    virtual void inserisci();
};

#endif // LAYOUTINSERISCI_H
