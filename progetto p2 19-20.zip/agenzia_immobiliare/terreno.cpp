#include "terreno.h"


terreno::terreno(string i, int s_t, string a, string co,
                 double p_b, string dest, bool vend,
                 bool edif, bool piant, int sup_edif, bool comm) :
    vendita(i,s_t,a,co,p_b,dest,vend),
    edificabile(edif), piantamento(piant), superficie_edif(sup_edif), commerciale(comm) {}


string terreno::getTipo() const{

    return "Terreno";
}

bool terreno::getEdif() const
{
    return edificabile;
}

bool terreno::getPiant() const
{
    return piantamento;
}

int terreno::getSup_edif() const
{
    return superficie_edif;
}

bool terreno::getComm() const
{
    return commerciale;
}

void terreno::setEdif(bool edifici)
{
    edificabile=edifici;
}

void terreno::setPiant(bool piante)
{
    piantamento=piante;
}

void terreno::setSup_Ed(int sup_e)
{
    superficie_edif=sup_e;
}

void terreno::setComm(bool commerc)
{
    commerciale=commerc;
}

double terreno::anticipo() const
{
    return prezzoFinale()*0.03;
}

double terreno::prezzoFinale() const
{
    double prezzoF= getPrezzo_base();

    if(edificabile == true)
        prezzoF += (prezzoF * 0.01);
    if(edificabile== true && commerciale == true)
        prezzoF= prezzoF + (prezzoF * 0.20);
    if(edificabile==false && piantamento == true)
        prezzoF = prezzoF + (prezzoF * 0.15);
    if(getSup_tot() > 600)
        prezzoF += (prezzoF * 0.15);
    return prezzoF;
}

double terreno::commissione_guadagno() const
{
    if(getproprietario()=="Agenzia" || getproprietario()=="Pagi" || getproprietario()=="PaGi"){
        return prezzoFinale();
    }
    else{
        return prezzoFinale()*0.15;
    }
}

terreno *terreno::clone() const
{
    return new terreno(*this);
}
