#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <model.h>
#include <mainwindow.h>
#include <addimmobilewindow.h>
#include <modimmobilewindow.h>
#include <visualizza_dettagli.h>
#include <comboimmobile.h>

#include <QObject>
#include <QStringList>
#include <QString>
#include <vector>
#include <QVector>
#include<QDate>
using namespace::std;


class controller : public QObject
{
    Q_OBJECT

public:
    explicit controller(QObject *parent = nullptr);
    ~controller();
    void errore1();
    void errore2();
    void errore3();
    void errore4();
    void errore5();
    void aggiornaListaImmobili(bool userFiltered);

public slots:

    void apriInserImmobile() const;

    void slotChiudiTutto();
    void slotFiltroVilla();
    void slotFiltroAppartamento();
    void slotFiltroTerreno();
    void slotFiltroVillaSingola();
    void slotFiltroTerrenoEdificabile();
    void slotFiltroTerrenoAgricolo();
    void slotFiltroAffittabile();
    void slotFiltroInVendita();
    void slotRimuoviFiltro();

    void slotFiltroAppSpese();
    void slotFiltroVillaSchiera();
    void slotFiltroImmobPropri();
    void slotFiltroAppAttico();

    void slotVisImmob();
    void slotModImmob();
    void slotEseguiMod();
    void slotAggiungiImmobile();
    void slotRimuoviImmobile();

    void slotFiltroParola();

private:

    model*m;
    mainwindow *view;
    addimmobilewindow *ins;
    modimmobilewindow *mod;
    vector<VisualizzaDettagli*> dettagli;

};

#endif // CONTROLLER_H
