#include "affitto.h"

affitto::affitto(string i, int s_t, string a, string co,
                 double p_m, int d_c, bool disp) :
    immobile(i, s_t, a, co), prezzo_mensile(p_m), durata_contratto(d_c), disponibilita(disp) {}

double affitto::getPrezzoMens() const
{
    return prezzo_mensile;
}

int affitto::getContratto() const
{
    return durata_contratto;
}

bool affitto::getDisponib() const
{
    return disponibilita;
}


void affitto::setPrezzoMens(double prezzo_mens)
{
    prezzo_mensile=prezzo_mens;
}

void affitto::setContratto(int periodo){
    durata_contratto=periodo;
}

void affitto::setDisponib(bool libero){
    disponibilita=libero;
}


