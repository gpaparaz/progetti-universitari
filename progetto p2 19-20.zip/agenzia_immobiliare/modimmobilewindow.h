#ifndef MODIMMOBILEWINDOW_H
#define MODIMMOBILEWINDOW_H
#include <mainwindow.h>
#include <database.h>
#include <model.h>
#include <immobile.h>
#include <QWidget>
#include <QStringList>

#include<QWidget>
#include<addimmobilewindow.h>

class modimmobilewindow : public addimmobilewindow
{
    Q_OBJECT
private:
    immobile* imm;

public:
    explicit modimmobilewindow(QWidget *parent = nullptr);
    void caricaCampiModifica(listaImmobiliOggetto* imm);
    void setImmobileDaModificare(immobile*imm);
    immobile* getImmobileDaModificare();
    void clear();
    ~modimmobilewindow();

signals:
    void signalModificaI();

public slots:
    void inserisci() override;
};

#endif // MODIMMOBILEWINDOW_H
