#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include<QVBoxLayout>
#include<QGroupBox>
#include<QHBoxLayout>
#include<QFormLayout>
#include<QLineEdit>
#include<QPushButton>
#include<QListWidget>
#include<QMessageBox>
#include<QCloseEvent>
#include<QPalette>
#include<QGridLayout>
#include<QIcon>
#include<QPixmap>

#include <affitto.h>
#include <vendita.h>
#include <immobile.h>
#include <edifici.h>
#include <terreno.h>
#include <appartamento.h>
#include <villa.h>
#include <database.h>
#include <model.h>
#include <addimmobilewindow.h>
#include <listaimmobili.h>


class mainwindow: public QWidget
{

public:
    mainwindow(QWidget *parent=nullptr);

    void mostraClienti(const QStringList);
    bool isSelected() const;
    listaimmobili* getIommobileListWidget();

    const QString getCampoCerca() const;


signals:
    void signalFiltroVilla();
    void signalFiltroAppartamento();
    void signalFiltroTerreno();
    void signalFiltroVillaSingola();
    void signalFiltroTerrenoEdificabile();
    void signalFiltroTerrenoAgricolo();
    void signalFiltroAffittabile();
    void signalFiltroInVendita();

    void signalFiltroVillaSchiera();
    void signalFiltroAppSpese();
    void signalFiltroAppAttico();
    void signalFiltroImmobPropri();

    void signalApriInserisci();
    void signalVisualizzaImmob();
    void signalModificaImmob();
    void signalRimuoviImmobile();
    void signalRimuoviFiltro();
    void esci();

    void signalCercaCampo();

private:
    Q_OBJECT

    QVBoxLayout *finestra_base;
    QGroupBox *risultati, *filtri, *ven_aff_filtri, *bottoni_modifica;
    QHBoxLayout *layout_bottoni_modifica, *flayout_ven_aff, *layout_filtri;
    QPushButton *inserisci_immobile, *rimuovi_immobile, *modifica_immobile, *visualizza_immobile,
    *filtroVille, *filtroTerreni, *filtroAppartamenti, *filtroVilleSingole, *filtroTerreniEdif,
    *filtroTerreniAgric, *filtroAffittabili, *filtroInVendita, *rimuoviFiltri, *filtroImmobiliProp,
    *filtroVilleSchiera, *filtroAppartSpese, *filtroAppAttico;
    listaimmobili *elencoImmobili;
    QLineEdit* ricerca;

    void closeEvent(QCloseEvent*) override;

};

#endif // MAINWINDOW_H
