#include "appartamento.h"


appartamento::appartamento(string i, int s_t, string a, string co,
                           double p_b, string dest, bool vend,
                           double p_m, int d_c, bool disp,
                           int p_a, int b, int c_l, int t, string c_e, int a_c,
                            bool lift, int pi, double s_c, bool att) :
    edifici(i, s_t, a, co, p_b, dest, vend, p_m, d_c, disp, p_a, b, c_l, t, c_e, a_c),
    ascensore (lift), piano(pi), spese_condominio(s_c), attico(att) {}


string appartamento::getTipo() const{

    return "Appartamento";
}

bool appartamento::getLift() const
{
    return ascensore;
}

int appartamento::getPiano() const
{
    return piano;
}

double appartamento::getSpese() const
{
    return spese_condominio;
}

bool appartamento::getAttico() const
{
    return attico;
}

void appartamento::setAscensore(bool lift)
{
    ascensore=lift;
}

void appartamento::setPiano(int altezza)
{
    piano=altezza;
}

void appartamento::setSpeseCond(double spese)
{
    spese_condominio=spese;
}

void appartamento::setAttico(bool att)
{
    attico=att;
}

double appartamento::prezzoFinale() const
{
    double prezzoF= getPrezzo_base();

    if(ascensore && piano > 8)
        prezzoF = prezzoF + (prezzoF * 0.06);
    if(!ascensore && piano> 4)
        prezzoF = prezzoF - (prezzoF * 0.03);
    if(spese_condominio > 2000 )
        prezzoF = prezzoF - (prezzoF * 0.04 );
    if(attico==true)
        prezzoF = prezzoF + (prezzoF * 0.10 );
    if(getSup_tot()> 250)
        prezzoF += (prezzoF * 0.15);

    return prezzoF;
}

double appartamento::anticipo() const
{
    return prezzoFinale()*0.05;
}

double appartamento::commissione_affitto() const
{
    return getPrezzoMens()* 0.25;
}

double appartamento::commissione_guadagno() const
{
    if(getproprietario()=="Agenzia" || getproprietario()=="Pagi" || getproprietario()=="PaGi"){
        return prezzoFinale();
    }
    else{
        return prezzoFinale()*0.20;
    }
}

appartamento *appartamento::clone() const
{
    return new appartamento(*this);
}
